package com.example.fast_video_compressor

import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : FlutterActivity() {
    companion object {
        private const val METHOD_CHANNEL = "com.example.fast_video_compressor/methods"
        private const val EVENT_CHANNEL = "com.example.fast_video_compressor/events"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cancelFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private var eventSink: EventChannel.EventSink? = null
    private lateinit var transcoder: HardwareVideoTranscoder

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        transcoder = HardwareVideoTranscoder(applicationContext)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            METHOD_CHANNEL
        ).setMethodCallHandler { call, result ->
            handleMethodCall(call, result)
        }

        EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            EVENT_CHANNEL
        ).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                eventSink = events
            }

            override fun onCancel(arguments: Any?) {
                eventSink = null
            }
        })
    }

    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "getVideoMetadata" -> {
                val path = call.argument<String>("path")
                if (path.isNullOrBlank()) {
                    result.error("INVALID_ARGS", "Video path is required", null)
                    return
                }
                scope.launch {
                    try {
                        val info = transcoder.inspectVideo(path)
                        val map = mapOf(
                            "path" to info.path,
                            "width" to info.width,
                            "height" to info.height,
                            "rotation" to info.rotation,
                            "durationMs" to info.durationMs,
                            "bitrateBps" to info.bitrateBps,
                            "fps" to info.fps,
                            "sizeBytes" to info.sizeBytes,
                            "hasAudio" to info.hasAudio,
                            "videoCodec" to info.videoCodec
                        )
                        withContext(Dispatchers.Main) {
                            result.success(map)
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            result.error("METADATA_ERROR", e.message, null)
                        }
                    }
                }
            }

            "compressVideo" -> {
                val taskId = call.argument<String>("taskId") ?: System.currentTimeMillis().toString()
                val inputPath = call.argument<String>("inputPath")
                val outputPath = call.argument<String>("outputPath")
                val targetWidth = call.argument<Int>("targetWidth") ?: 1280
                val targetHeight = call.argument<Int>("targetHeight") ?: 720
                val targetBitrate = call.argument<Int>("targetBitrate") ?: 2_500_000
                val targetFps = call.argument<Int>("targetFps") ?: 30
                val preferHevc = call.argument<Boolean>("preferHevc") ?: true
                val audioPassthrough = call.argument<Boolean>("audioPassthrough") ?: true

                if (inputPath.isNullOrBlank() || outputPath.isNullOrBlank()) {
                    result.error("INVALID_ARGS", "inputPath and outputPath are required", null)
                    return
                }

                val cancelFlag = AtomicBoolean(false)
                cancelFlags[taskId] = cancelFlag

                scope.launch {
                    try {
                        val outcome = transcoder.transcode(
                            config = TranscodeConfig(
                                taskId = taskId,
                                inputPath = inputPath,
                                outputPath = outputPath,
                                targetWidth = targetWidth,
                                targetHeight = targetHeight,
                                targetBitrate = targetBitrate,
                                targetFps = targetFps,
                                preferHevc = preferHevc,
                                enableAudioPassthrough = audioPassthrough
                            ),
                            cancelFlag = cancelFlag,
                            onProgress = { prog ->
                                emitProgressEvent(
                                    mapOf(
                                        "taskId" to prog.taskId,
                                        "progress" to prog.progress,
                                        "fps" to prog.currentFps,
                                        "etaSeconds" to prog.etaSeconds,
                                        "status" to prog.status
                                    )
                                )
                            }
                        )
                        withContext(Dispatchers.Main) {
                            result.success(outcome)
                        }
                    } catch (ie: InterruptedException) {
                        emitProgressEvent(
                            mapOf(
                                "taskId" to taskId,
                                "progress" to 0.0,
                                "fps" to 0.0,
                                "etaSeconds" to 0,
                                "status" to "cancelled"
                            )
                        )
                        withContext(Dispatchers.Main) {
                            result.error("CANCELLED", ie.message ?: "Cancelled", null)
                        }
                    } catch (e: Exception) {
                        emitProgressEvent(
                            mapOf(
                                "taskId" to taskId,
                                "progress" to 0.0,
                                "fps" to 0.0,
                                "etaSeconds" to 0,
                                "status" to "failed",
                                "error" to (e.message ?: "Unknown error")
                            )
                        )
                        withContext(Dispatchers.Main) {
                            result.error("TRANSCODE_FAILED", e.message, null)
                        }
                    } finally {
                        cancelFlags.remove(taskId)
                    }
                }
            }

            "cancelTask" -> {
                val taskId = call.argument<String>("taskId")
                if (taskId != null) {
                    cancelFlags[taskId]?.set(true)
                }
                result.success(true)
            }

            "saveToGallery" -> {
                val path = call.argument<String>("path")
                if (path.isNullOrBlank()) {
                    result.error("INVALID_ARGS", "path is required", null)
                    return
                }
                scope.launch {
                    try {
                        val savedUri = transcoder.saveVideoToGallery(path)
                        withContext(Dispatchers.Main) {
                            result.success(savedUri)
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            result.error("SAVE_FAILED", e.message, null)
                        }
                    }
                }
            }

            "deleteOriginalVideo" -> {
                val path = call.argument<String>("path")
                if (path.isNullOrBlank()) {
                    result.error("INVALID_ARGS", "path is required", null)
                    return
                }
                scope.launch {
                    val deleted = try {
                        val file = File(path)
                        file.exists() && file.delete()
                    } catch (_: Exception) {
                        false
                    }
                    withContext(Dispatchers.Main) {
                        result.success(deleted)
                    }
                }
            }

            else -> result.notImplemented()
        }
    }

    private fun emitProgressEvent(payload: Map<String, Any>) {
        mainHandler.post {
            eventSink?.success(payload)
        }
    }

    override fun onDestroy() {
        for ((_, flag) in cancelFlags) {
            flag.set(true)
        }
        scope.cancel()
        super.onDestroy()
    }
}
