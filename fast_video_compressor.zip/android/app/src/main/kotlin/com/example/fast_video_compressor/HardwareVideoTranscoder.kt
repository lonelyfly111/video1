package com.example.fast_video_compressor

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.fast_video_compressor.gl.InputSurface
import com.example.fast_video_compressor.gl.OutputSurface
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.roundToInt

data class VideoMetadataInfo(
    val path: String,
    val width: Int,
    val height: Int,
    val rotation: Int,
    val durationMs: Long,
    val bitrateBps: Int,
    val fps: Double,
    val sizeBytes: Long,
    val hasAudio: Boolean,
    val videoCodec: String
)

data class TranscodeConfig(
    val taskId: String,
    val inputPath: String,
    val outputPath: String,
    val targetWidth: Int,
    val targetHeight: Int,
    val targetBitrate: Int,
    val targetFps: Int,
    val preferHevc: Boolean,
    val enableAudioPassthrough: Boolean = true
)

data class TranscodeProgress(
    val taskId: String,
    val progress: Double,
    val currentFps: Double,
    val etaSeconds: Int,
    val status: String
)

class HardwareVideoTranscoder(private val context: Context) {

    /**
     * Extracts accurate source video metadata using MediaMetadataRetriever + MediaExtractor.
     */
    fun inspectVideo(path: String): VideoMetadataInfo {
        val file = File(path)
        val sizeBytes = if (file.exists()) file.length() else 0L
        val retriever = MediaMetadataRetriever()
        var width = 1920
        var height = 1080
        var rotation = 0
        var durationMs = 0L
        var bitrateBps = 0
        var fps = 30.0
        var hasAudio = false
        var videoCodec = "video/avc"

        try {
            retriever.setDataSource(path)
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 1920
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 1080
            rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            bitrateBps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toIntOrNull() ?: 0
            val captureFps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
                ?.toDoubleOrNull()
            if (captureFps != null && captureFps > 0) {
                fps = captureFps
            }
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(path)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoCodec = mime
                    if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = format.getInteger(MediaFormat.KEY_FRAME_RATE).toDouble()
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        format.containsKey(MediaFormat.KEY_ROTATION)
                    ) {
                        rotation = format.getInteger(MediaFormat.KEY_ROTATION)
                    }
                } else if (mime.startsWith("audio/")) {
                    hasAudio = true
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {
            }
        }

        if (bitrateBps <= 0 && durationMs > 0 && sizeBytes > 0) {
            bitrateBps = ((sizeBytes * 8L * 1000L) / durationMs).toInt()
        }

        return VideoMetadataInfo(
            path = path,
            width = width,
            height = height,
            rotation = rotation,
            durationMs = durationMs,
            bitrateBps = bitrateBps,
            fps = fps,
            sizeBytes = sizeBytes,
            hasAudio = hasAudio,
            videoCodec = videoCodec
        )
    }

    /**
     * Checks whether the device has a hardware-accelerated encoder for the given MIME type.
     */
    private fun supportsHardwareEncoder(mimeType: String): Boolean {
        val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        for (info in codecList.codecInfos) {
            if (!info.isEncoder) continue
            val supportedTypes = info.supportedTypes
            val matchesMime = supportedTypes.any { it.equals(mimeType, ignoreCase = true) }
            if (!matchesMime) continue

            val isHardware = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.isHardwareAccelerated
            } else {
                val name = info.name.lowercase()
                !name.startsWith("omx.google.") &&
                    !name.startsWith("c2.android.") &&
                    !name.contains(".sw.")
            }
            if (isHardware) return true
        }
        return false
    }

    /**
     * Executes the complete hardware-accelerated video transcode + lossless audio passthrough pipeline.
     * Cleans up partial output files automatically if cancelled or if an exception occurs.
     */
    fun transcode(
        config: TranscodeConfig,
        cancelFlag: AtomicBoolean,
        onProgress: (TranscodeProgress) -> Unit
    ): Map<String, Any> {
        val outputFile = File(config.outputPath)
        outputFile.parentFile?.mkdirs()
        if (outputFile.exists()) {
            outputFile.delete()
        }

        var videoExtractor: MediaExtractor? = null
        var audioExtractor: MediaExtractor? = null
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var inputSurface: InputSurface? = null
        var outputSurface: OutputSurface? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var completedNormally = false

        val startTimeNs = System.nanoTime()

        try {
            val meta = inspectVideo(config.inputPath)
            val totalDurationUs = max(1L, meta.durationMs * 1000L)

            videoExtractor = MediaExtractor().apply { setDataSource(config.inputPath) }
            var videoTrackIndex = -1
            var inputVideoFormat: MediaFormat? = null

            for (i in 0 until videoExtractor.trackCount) {
                val format = videoExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    inputVideoFormat = format
                    break
                }
            }

            if (videoTrackIndex < 0 || inputVideoFormat == null) {
                throw IllegalArgumentException("No valid video track found in ${config.inputPath}")
            }
            videoExtractor.selectTrack(videoTrackIndex)

            // Read source rotation metadata so portrait videos are never sideways
            val rotationDegrees = if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                inputVideoFormat.containsKey(MediaFormat.KEY_ROTATION)
            ) {
                inputVideoFormat.getInteger(MediaFormat.KEY_ROTATION)
            } else {
                meta.rotation
            }

            // Ensure target dimensions are strictly even integers (required by H.264/HEVC hardware codecs)
            val alignedWidth = max(2, config.targetWidth and 1.inv())
            val alignedHeight = max(2, config.targetHeight and 1.inv())

            // Select codec MIME type: prioritize video/hevc (H.265) when requested and supported
            val selectedMime = if (
                config.preferHevc && supportsHardwareEncoder(MediaFormat.MIMETYPE_VIDEO_HEVC)
            ) {
                MediaFormat.MIMETYPE_VIDEO_HEVC
            } else {
                MediaFormat.MIMETYPE_VIDEO_AVC
            }

            val outputVideoFormat = MediaFormat.createVideoFormat(
                selectedMime,
                alignedWidth,
                alignedHeight
            ).apply {
                setInteger(
                    MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
                )
                setInteger(MediaFormat.KEY_BIT_RATE, config.targetBitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, config.targetFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    setInteger(MediaFormat.KEY_ROTATION, rotationDegrees)
                }
                // Preserve color standard / HDR-to-SDR transfer metadata if present in source
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    if (inputVideoFormat.containsKey(MediaFormat.KEY_COLOR_STANDARD)) {
                        setInteger(
                            MediaFormat.KEY_COLOR_STANDARD,
                            inputVideoFormat.getInteger(MediaFormat.KEY_COLOR_STANDARD)
                        )
                    }
                    if (inputVideoFormat.containsKey(MediaFormat.KEY_COLOR_RANGE)) {
                        setInteger(
                            MediaFormat.KEY_COLOR_RANGE,
                            inputVideoFormat.getInteger(MediaFormat.KEY_COLOR_RANGE)
                        )
                    }
                    if (inputVideoFormat.containsKey(MediaFormat.KEY_COLOR_TRANSFER)) {
                        setInteger(
                            MediaFormat.KEY_COLOR_TRANSFER,
                            inputVideoFormat.getInteger(MediaFormat.KEY_COLOR_TRANSFER)
                        )
                    }
                }
            }

            // Configure Hardware Encoder + EGL InputSurface
            encoder = MediaCodec.createEncoderByType(selectedMime)
            encoder.configure(outputVideoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = InputSurface(encoder.createInputSurface())
            inputSurface.makeCurrent()
            encoder.start()

            // Configure OpenGL ES OutputSurface + Hardware Decoder
            outputSurface = OutputSurface(alignedWidth, alignedHeight)
            val inputMime = inputVideoFormat.getString(MediaFormat.KEY_MIME)
                ?: MediaFormat.MIMETYPE_VIDEO_AVC
            decoder = MediaCodec.createDecoderByType(inputMime)
            decoder.configure(inputVideoFormat, outputSurface.surface, null, 0)
            decoder.start()

            // Configure MediaMuxer and preserve rotation matrix in container header (tkhd)
            muxer = MediaMuxer(config.outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            if (rotationDegrees == 90 || rotationDegrees == 180 || rotationDegrees == 270) {
                muxer.setOrientationHint(rotationDegrees)
            }

            // Prepare Optional Lossless Audio Track Passthrough
            var sourceAudioTrackIndex = -1
            var muxerAudioTrackIndex = -1
            var inputAudioFormat: MediaFormat? = null
            if (config.enableAudioPassthrough) {
                audioExtractor = MediaExtractor().apply { setDataSource(config.inputPath) }
                for (i in 0 until audioExtractor.trackCount) {
                    val format = audioExtractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) {
                        sourceAudioTrackIndex = i
                        inputAudioFormat = format
                        audioExtractor.selectTrack(i)
                        break
                    }
                }
            }

            var muxerVideoTrackIndex = -1
            val decoderBufferInfo = MediaCodec.BufferInfo()
            val encoderBufferInfo = MediaCodec.BufferInfo()

            var extractorDone = false
            var decoderDone = false
            var encoderDone = false
            var framesEncoded = 0
            var lastProgressReportMs = 0L

            val timeoutUs = 10_000L

            while (!encoderDone) {
                if (cancelFlag.get()) {
                    throw InterruptedException("Task ${config.taskId} cancelled by user")
                }

                // Step 1: Feed compressed samples from MediaExtractor into Hardware Decoder
                if (!extractorDone) {
                    val inputBufIndex = decoder.dequeueInputBuffer(timeoutUs)
                    if (inputBufIndex >= 0) {
                        val inputBuf = decoder.getInputBuffer(inputBufIndex)!!
                        val sampleSize = videoExtractor.readSampleData(inputBuf, 0)
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(
                                inputBufIndex,
                                0,
                                0,
                                0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            extractorDone = true
                        } else {
                            val presentationTimeUs = videoExtractor.sampleTime
                            decoder.queueInputBuffer(
                                inputBufIndex,
                                0,
                                sampleSize,
                                presentationTimeUs,
                                0
                            )
                            videoExtractor.advance()
                        }
                    }
                }

                // Step 2: Drain decoded frames to OpenGL ES OutputSurface -> InputSurface -> Encoder
                var decoderOutputAvailable = !decoderDone
                while (decoderOutputAvailable) {
                    val status = decoder.dequeueOutputBuffer(decoderBufferInfo, timeoutUs)
                    when {
                        status == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            decoderOutputAvailable = false
                        }
                        status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            // Decoder output format negotiated
                        }
                        status >= 0 -> {
                            val doRender = decoderBufferInfo.size != 0
                            decoder.releaseOutputBuffer(status, doRender)
                            if (doRender) {
                                outputSurface.awaitNewImage()
                                outputSurface.drawImage()
                                inputSurface.setPresentationTime(
                                    decoderBufferInfo.presentationTimeUs * 1000L
                                )
                                inputSurface.swapBuffers()
                            }
                            if ((decoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                encoder.signalEndOfInputStream()
                                decoderDone = true
                                decoderOutputAvailable = false
                            }
                        }
                    }

                    // Drain available encoded packets immediately to prevent pipeline backpressure
                    while (true) {
                        val encStatus = encoder.dequeueOutputBuffer(encoderBufferInfo, 0L)
                        when {
                            encStatus == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                            encStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                if (muxerStarted) {
                                    throw IllegalStateException("Encoder format changed twice")
                                }
                                muxerVideoTrackIndex = muxer.addTrack(encoder.outputFormat)
                                if (sourceAudioTrackIndex >= 0 && inputAudioFormat != null) {
                                    try {
                                        muxerAudioTrackIndex = muxer.addTrack(inputAudioFormat)
                                    } catch (_: Exception) {
                                        muxerAudioTrackIndex = -1
                                    }
                                }
                                muxer.start()
                                muxerStarted = true
                            }
                            encStatus >= 0 -> {
                                val encodedData = encoder.getOutputBuffer(encStatus)
                                    ?: throw RuntimeException("Encoder output buffer was null")
                                if ((encoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                    encoderBufferInfo.size = 0
                                }
                                if (encoderBufferInfo.size != 0 && muxerStarted) {
                                    encodedData.position(encoderBufferInfo.offset)
                                    encodedData.limit(encoderBufferInfo.offset + encoderBufferInfo.size)
                                    muxer.writeSampleData(
                                        muxerVideoTrackIndex,
                                        encodedData,
                                        encoderBufferInfo
                                    )
                                    framesEncoded++

                                    val nowMs = System.currentTimeMillis()
                                    if (nowMs - lastProgressReportMs >= 120L) {
                                        lastProgressReportMs = nowMs
                                        val elapsedSec = max(
                                            0.001,
                                            (System.nanoTime() - startTimeNs) / 1_000_000_000.0
                                        )
                                        val currentFps = framesEncoded / elapsedSec
                                        val rawProgress = (encoderBufferInfo.presentationTimeUs.toDouble() /
                                            totalDurationUs.toDouble()).coerceIn(0.0, 0.98)
                                        val remainingSec = if (rawProgress > 0.02) {
                                            ((elapsedSec / rawProgress) * (1.0 - rawProgress)).roundToInt()
                                        } else {
                                            0
                                        }
                                        onProgress(
                                            TranscodeProgress(
                                                taskId = config.taskId,
                                                progress = rawProgress,
                                                currentFps = currentFps,
                                                etaSeconds = max(0, remainingSec),
                                                status = "running"
                                            )
                                        )
                                    }
                                }
                                encoder.releaseOutputBuffer(encStatus, false)
                                if ((encoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                    encoderDone = true
                                    break
                                }
                            }
                        }
                    }
                }

                // Step 3: If decoder has finished, keep draining encoder until EOS
                if (decoderDone && !encoderDone) {
                    val encStatus = encoder.dequeueOutputBuffer(encoderBufferInfo, timeoutUs)
                    when {
                        encStatus == MediaCodec.INFO_TRY_AGAIN_LATER -> {}
                        encStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (!muxerStarted) {
                                muxerVideoTrackIndex = muxer.addTrack(encoder.outputFormat)
                                if (sourceAudioTrackIndex >= 0 && inputAudioFormat != null) {
                                    try {
                                        muxerAudioTrackIndex = muxer.addTrack(inputAudioFormat)
                                    } catch (_: Exception) {
                                        muxerAudioTrackIndex = -1
                                    }
                                }
                                muxer.start()
                                muxerStarted = true
                            }
                        }
                        encStatus >= 0 -> {
                            val encodedData = encoder.getOutputBuffer(encStatus)!!
                            if ((encoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                encoderBufferInfo.size = 0
                            }
                            if (encoderBufferInfo.size != 0 && muxerStarted) {
                                encodedData.position(encoderBufferInfo.offset)
                                encodedData.limit(encoderBufferInfo.offset + encoderBufferInfo.size)
                                muxer.writeSampleData(
                                    muxerVideoTrackIndex,
                                    encodedData,
                                    encoderBufferInfo
                                )
                                framesEncoded++
                            }
                            encoder.releaseOutputBuffer(encStatus, false)
                            if ((encoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                encoderDone = true
                            }
                        }
                    }
                }
            }

            // Step 4: Lossless Audio Track Passthrough (Direct SampleBuffer Stream Copy)
            if (muxerStarted && muxerAudioTrackIndex >= 0 && audioExtractor != null) {
                val audioBuffer = ByteBuffer.allocateDirect(256 * 1024)
                val audioBufferInfo = MediaCodec.BufferInfo()
                while (true) {
                    if (cancelFlag.get()) {
                        throw InterruptedException("Task ${config.taskId} cancelled during audio muxing")
                    }
                    audioBuffer.clear()
                    val sampleSize = audioExtractor.readSampleData(audioBuffer, 0)
                    if (sampleSize < 0) break

                    audioBufferInfo.offset = 0
                    audioBufferInfo.size = sampleSize
                    audioBufferInfo.presentationTimeUs = audioExtractor.sampleTime
                    audioBufferInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrackIndex, audioBuffer, audioBufferInfo)
                    audioExtractor.advance()
                }
            }

            completedNormally = true
            val finalElapsedSec = max(0.001, (System.nanoTime() - startTimeNs) / 1_000_000_000.0)
            val avgFps = framesEncoded / finalElapsedSec

            onProgress(
                TranscodeProgress(
                    taskId = config.taskId,
                    progress = 1.0,
                    currentFps = avgFps,
                    etaSeconds = 0,
                    status = "completed"
                )
            )

            val compressedMeta = inspectVideo(config.outputPath)
            return mapOf(
                "taskId" to config.taskId,
                "outputPath" to config.outputPath,
                "outputSizeBytes" to outputFile.length(),
                "outputWidth" to compressedMeta.width,
                "outputHeight" to compressedMeta.height,
                "outputBitrate" to compressedMeta.bitrateBps,
                "codecUsed" to selectedMime,
                "averageFps" to avgFps,
                "elapsedMs" to (finalElapsedSec * 1000).roundToInt()
            )
        } finally {
            // Strict try-finally resource cleanup to protect hardware codec instances
            try {
                decoder?.stop()
            } catch (_: Exception) {
            }
            try {
                decoder?.release()
            } catch (_: Exception) {
            }
            try {
                outputSurface?.release()
            } catch (_: Exception) {
            }
            try {
                encoder?.stop()
            } catch (_: Exception) {
            }
            try {
                encoder?.release()
            } catch (_: Exception) {
            }
            try {
                inputSurface?.release()
            } catch (_: Exception) {
            }
            try {
                videoExtractor?.release()
            } catch (_: Exception) {
            }
            try {
                audioExtractor?.release()
            } catch (_: Exception) {
            }
            try {
                if (muxerStarted) {
                    muxer?.stop()
                }
            } catch (_: Exception) {
            }
            try {
                muxer?.release()
            } catch (_: Exception) {
            }

            // Automatically clean up temporary/partial output file if interrupted or failed
            if (!completedNormally && outputFile.exists()) {
                outputFile.delete()
            }
        }
    }

    /**
     * Saves a compressed video file to the public system gallery (Movies/FastVideoCompressor)
     * via MediaStore so it appears immediately in the user's Photos/Gallery app.
     */
    fun saveVideoToGallery(videoPath: String): String {
        val sourceFile = File(videoPath)
        if (!sourceFile.exists()) {
            throw IllegalArgumentException("Compressed file does not exist: $videoPath")
        }
        val resolver = context.contentResolver
        val fileName = "FastCompress_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/FastVideoCompressor"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collectionUri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collectionUri, values)
            ?: throw RuntimeException("Failed to create MediaStore entry")

        resolver.openOutputStream(itemUri)?.use { outStream ->
            FileInputStream(sourceFile).use { inStream ->
                inStream.copyTo(outStream, bufferSize = 256 * 1024)
            }
        } ?: throw RuntimeException("Failed to open MediaStore output stream")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val completedValues = ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }
            resolver.update(itemUri, completedValues, null, null)
        }
        return itemUri.toString()
    }
}
