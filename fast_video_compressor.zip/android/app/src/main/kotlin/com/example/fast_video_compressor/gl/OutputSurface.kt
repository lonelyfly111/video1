package com.example.fast_video_compressor.gl

import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface

/**
 * Holds a SurfaceTexture and Surface passed to MediaCodec.configure() on the decoder.
 * Waits for onFrameAvailable callbacks on a dedicated HandlerThread so it never deadlocks
 * the calling coroutine/worker thread, then draws the external OES texture onto the active
 * InputSurface EGL context.
 */
class OutputSurface(
    targetWidth: Int,
    targetHeight: Int
) : SurfaceTexture.OnFrameAvailableListener {

    private var textureRenderer: TextureRenderer? = TextureRenderer(targetWidth, targetHeight)
    private var surfaceTexture: SurfaceTexture? = null
    var surface: Surface? = null
        private set

    private val frameSyncObject = Object()
    private var frameAvailable = false
    private var callbackThread: HandlerThread? = null
    private var callbackHandler: Handler? = null

    init {
        setup()
    }

    private fun setup() {
        val renderer = textureRenderer ?: throw IllegalStateException("Renderer is null")
        renderer.surfaceCreated()

        callbackThread = HandlerThread("OutputSurfaceFrameListener").apply { start() }
        callbackHandler = Handler(callbackThread!!.looper)

        surfaceTexture = SurfaceTexture(renderer.textureId).apply {
            setOnFrameAvailableListener(this@OutputSurface, callbackHandler)
        }
        surface = Surface(surfaceTexture)
    }

    fun release() {
        surface?.release()
        surface = null
        surfaceTexture?.release()
        surfaceTexture = null
        textureRenderer = null
        callbackThread?.quitSafely()
        callbackThread = null
        callbackHandler = null
    }

    fun awaitNewImage() {
        val timeoutMs = 2500L
        synchronized(frameSyncObject) {
            while (!frameAvailable) {
                try {
                    frameSyncObject.wait(timeoutMs)
                    if (!frameAvailable) {
                        throw RuntimeException("Surface frame wait timed out after ${timeoutMs}ms")
                    }
                } catch (ie: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw RuntimeException(ie)
                }
            }
            frameAvailable = false
        }
        textureRenderer?.checkGlError("before updateTexImage")
        surfaceTexture?.updateTexImage()
    }

    fun drawImage() {
        val st = surfaceTexture ?: return
        textureRenderer?.drawFrame(st)
    }

    override fun onFrameAvailable(st: SurfaceTexture) {
        synchronized(frameSyncObject) {
            if (frameAvailable) {
                throw RuntimeException("frameAvailable already set, frame could be dropped")
            }
            frameAvailable = true
            frameSyncObject.notifyAll()
        }
    }
}
