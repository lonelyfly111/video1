import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models/video_task.dart';
import '../services/compression_queue_controller.dart';
import '../utils/format_utils.dart';

enum PreviewComparisonMode {
  splitScreen, // 分屏 Wipe 滑块实时对比
  sideBySideToggle, // 左右快速切换原片/压缩片
}

class ResultComparisonScreen extends StatefulWidget {
  final CompressionQueueController controller;
  final VideoCompressionTask task;

  const ResultComparisonScreen({
    super.key,
    required this.controller,
    required this.task,
  });

  @override
  State<ResultComparisonScreen> createState() => _ResultComparisonScreenState();
}

class _ResultComparisonScreenState extends State<ResultComparisonScreen> {
  VideoPlayerController? _originalPlayer;
  VideoPlayerController? _compressedPlayer;
  bool _playersInitialized = false;
  bool _isPlaying = false;
  PreviewComparisonMode _mode = PreviewComparisonMode.splitScreen;
  double _splitFraction = 0.5;
  bool _showingCompressedInToggle = true;

  @override
  void initState() {
    super.initState();
    _initVideoPlayers();
  }

  Future<void> _initVideoPlayers() async {
    final res = widget.task.result;
    if (res == null) return;
    final origFile = File(widget.task.source.path);
    final compFile = File(res.outputPath);

    if (!origFile.existsSync() || !compFile.existsSync()) return;

    final origCtrl = VideoPlayerController.file(origFile);
    final compCtrl = VideoPlayerController.file(compFile);
    try {
      await Future.wait([origCtrl.initialize(), compCtrl.initialize()]);
      await origCtrl.setLooping(true);
      await compCtrl.setLooping(true);
      await origCtrl.setVolume(0.0); // Avoid doubled audio echo during sync playback
      if (mounted) {
        setState(() {
          _originalPlayer = origCtrl;
          _compressedPlayer = compCtrl;
          _playersInitialized = true;
        });
      }
    } catch (e) {
      debugPrint('Failed initializing comparison players: $e');
    }
  }

  Future<void> _togglePlayPause() async {
    if (!_playersInitialized) return;
    if (_isPlaying) {
      await Future.wait([
        _originalPlayer!.pause(),
        _compressedPlayer!.pause(),
      ]);
    } else {
      final pos = await _compressedPlayer!.position ?? Duration.zero;
      await _originalPlayer!.seekTo(pos);
      await Future.wait([
        _originalPlayer!.play(),
        _compressedPlayer!.play(),
      ]);
    }
    if (mounted) {
      setState(() => _isPlaying = !_isPlaying);
    }
  }

  Future<void> _handleSaveToGallery() async {
    try {
      final uri = await widget.controller.saveResultToGallery(widget.task);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已保存到系统相册 ($uri)')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('保存失败: $e')),
        );
      }
    }
  }

  Future<void> _handleDeleteOriginal() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1F2937),
        title: const Text('删除原视频释放空间？', style: TextStyle(color: Colors.white)),
        content: Text(
          '删除后将立即释放 ${FormatUtils.formatBytes(widget.task.source.sizeBytes)} 存储空间。建议先将压缩后的视频保存到系统相册。',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('取消'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('确认删除'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final deleted = await widget.controller.deleteOriginalFile(widget.task);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(deleted ? '原视频已删除，空间已释放' : '原视频删除失败或需要系统授权'),
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _originalPlayer?.dispose();
    _compressedPlayer?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        final res = widget.task.result;
        if (res == null) {
          return Scaffold(
            backgroundColor: const Color(0xFF0B0F19),
            appBar: AppBar(title: const Text('对比详情')),
            body: const Center(
              child: Text('无可用压缩结果', style: TextStyle(color: Colors.white70)),
            ),
          );
        }

        return Scaffold(
          backgroundColor: const Color(0xFF0B0F19),
          appBar: AppBar(
            backgroundColor: const Color(0xFF0B0F19),
            title: const Text(
              '压缩前后效果对比',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            ),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 32),
            children: [
              _buildMetricsComparisonCard(res),
              const SizedBox(height: 20),
              _buildPreviewModeHeader(),
              const SizedBox(height: 12),
              _buildVideoPreviewCanvas(),
              const SizedBox(height: 24),
              _buildActionButtons(res),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMetricsComparisonCard(CompressionResult res) {
    final orig = widget.task.source;
    final savedBytes = widget.task.savedBytes;
    final savedPct = orig.sizeBytes > 0
        ? ((1.0 - (res.outputSizeBytes / orig.sizeBytes)) * 100).clamp(0.0, 99.0)
        : 0.0;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF131C31),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF1F2937)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFF065F46),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '已缩减 ${savedPct.toStringAsFixed(1)}% · 节省 ${FormatUtils.formatBytes(savedBytes)}',
                  style: const TextStyle(
                    color: Color(0xFF6EE7B7),
                    fontWeight: FontWeight.w700,
                    fontSize: 12.5,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                '耗时 ${(res.elapsedMs / 1000.0).toStringAsFixed(1)}s · ${res.averageFps.toStringAsFixed(1)} fps',
                style: const TextStyle(color: Colors.white60, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: Color(0xFF1F2937), height: 1),
          const SizedBox(height: 14),
          _buildComparisonRow(
            label: '文件体积',
            before: FormatUtils.formatBytes(orig.sizeBytes),
            after: FormatUtils.formatBytes(res.outputSizeBytes),
            highlightAfter: true,
          ),
          const SizedBox(height: 10),
          _buildComparisonRow(
            label: '视频码率',
            before: FormatUtils.formatBitrate(orig.bitrateBps),
            after: FormatUtils.formatBitrate(res.outputBitrateBps),
          ),
          const SizedBox(height: 10),
          _buildComparisonRow(
            label: '画面分辨率',
            before: orig.resolutionLabel,
            after: '${res.outputWidth}x${res.outputHeight}',
          ),
          const SizedBox(height: 10),
          _buildComparisonRow(
            label: '编码与音轨',
            before: orig.videoCodec,
            after: '${res.codecUsed} + 音轨直通',
          ),
        ],
      ),
    );
  }

  Widget _buildComparisonRow({
    required String label,
    required String before,
    required String after,
    bool highlightAfter = false,
  }) {
    return Row(
      children: [
        SizedBox(
          width: 84,
          child: Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 13),
          ),
        ),
        Expanded(
          child: Text(
            before,
            style: const TextStyle(color: Colors.white70, fontSize: 13.5),
          ),
        ),
        const Icon(Icons.arrow_forward_rounded,
            color: Colors.white38, size: 16),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            after,
            textAlign: TextAlign.right,
            style: TextStyle(
              color:
                  highlightAfter ? const Color(0xFF34D399) : Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPreviewModeHeader() {
    return Row(
      children: [
        const Text(
          '实时画质预览对比',
          style: TextStyle(
            color: Colors.white,
            fontSize: 15.5,
            fontWeight: FontWeight.w600,
          ),
        ),
        const Spacer(),
        SegmentedButton<PreviewComparisonMode>(
          segments: const [
            ButtonSegment(
              value: PreviewComparisonMode.splitScreen,
              label: Text('分屏滑块', style: TextStyle(fontSize: 12)),
            ),
            ButtonSegment(
              value: PreviewComparisonMode.sideBySideToggle,
              label: Text('左右切换', style: TextStyle(fontSize: 12)),
            ),
          ],
          selected: {_mode},
          onSelectionChanged: (s) => setState(() => _mode = s.first),
        ),
      ],
    );
  }

  Widget _buildVideoPreviewCanvas() {
    if (!_playersInitialized ||
        _originalPlayer == null ||
        _compressedPlayer == null) {
      return Container(
        height: 260,
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          borderRadius: BorderRadius.circular(18),
        ),
        child: const Center(
          child: Text(
            '正在加载原片与压缩片硬件解码预览...',
            style: TextStyle(color: Colors.white54, fontSize: 13),
          ),
        ),
      );
    }

    final aspectRatio = _compressedPlayer!.value.aspectRatio > 0
        ? _compressedPlayer!.value.aspectRatio
        : (16 / 9);

    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: AspectRatio(
            aspectRatio: aspectRatio.clamp(0.55, 2.2),
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (_mode == PreviewComparisonMode.splitScreen) ...[
                  VideoPlayer(_compressedPlayer!),
                  ClipRect(
                    clipper: _HorizontalSplitClipper(_splitFraction),
                    child: VideoPlayer(_originalPlayer!),
                  ),
                  Positioned(
                    left: 12,
                    top: 12,
                    child: _buildCornerTag('左：原视频', Colors.black87),
                  ),
                  Positioned(
                    right: 12,
                    top: 12,
                    child: _buildCornerTag(
                        '右：压缩后', const Color(0xFF065F46)),
                  ),
                ] else ...[
                  VideoPlayer(_showingCompressedInToggle
                      ? _compressedPlayer!
                      : _originalPlayer!),
                  Positioned(
                    left: 12,
                    top: 12,
                    child: _buildCornerTag(
                      _showingCompressedInToggle ? '当前：压缩后画质' : '当前：原视频画质',
                      _showingCompressedInToggle
                          ? const Color(0xFF065F46)
                          : Colors.black87,
                    ),
                  ),
                ],
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: FloatingActionButton.small(
                    backgroundColor: Colors.black.withOpacity(0.65),
                    onPressed: _togglePlayPause,
                    child: Icon(
                      _isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (_mode == PreviewComparisonMode.splitScreen)
          Row(
            children: [
              const Text('原片',
                  style: TextStyle(color: Colors.white60, fontSize: 12)),
              Expanded(
                child: Slider(
                  value: _splitFraction,
                  min: 0.05,
                  max: 0.95,
                  activeColor: const Color(0xFF06B6D4),
                  onChanged: (v) => setState(() => _splitFraction = v),
                ),
              ),
              const Text('压缩后',
                  style: TextStyle(color: Color(0xFF34D399), fontSize: 12)),
            ],
          )
        else
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ChoiceChip(
                label: const Text('查看原视频'),
                selected: !_showingCompressedInToggle,
                onSelected: (_) =>
                    setState(() => _showingCompressedInToggle = false),
              ),
              const SizedBox(width: 12),
              ChoiceChip(
                label: const Text('查看压缩后'),
                selected: _showingCompressedInToggle,
                onSelected: (_) =>
                    setState(() => _showingCompressedInToggle = true),
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildCornerTag(String label, Color bg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg.withOpacity(0.8),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildActionButtons(CompressionResult res) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF06B6D4),
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
          onPressed: res.savedToGallery ? null : _handleSaveToGallery,
          icon: Icon(
            res.savedToGallery
                ? Icons.check_circle_rounded
                : Icons.save_alt_rounded,
          ),
          label: Text(
            res.savedToGallery ? '已保存到系统相册' : '一键保存到系统相册',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
          ),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.redAccent,
            side: const BorderSide(color: Colors.redAccent),
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
          onPressed: res.originalDeleted ? null : _handleDeleteOriginal,
          icon: const Icon(Icons.delete_forever_rounded),
          label: Text(
            res.originalDeleted
                ? '原视频已删除'
                : '删除原视频释放空间 (${FormatUtils.formatBytes(widget.task.source.sizeBytes)})',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
          ),
        ),
      ],
    );
  }
}

class _HorizontalSplitClipper extends CustomClipper<Rect> {
  final double fraction;

  _HorizontalSplitClipper(this.fraction);

  @override
  Rect getClip(Size size) {
    return Rect.fromLTRB(0, 0, size.width * fraction, size.height);
  }

  @override
  bool shouldReclip(covariant _HorizontalSplitClipper oldClipper) {
    return oldClipper.fraction != fraction;
  }
}
