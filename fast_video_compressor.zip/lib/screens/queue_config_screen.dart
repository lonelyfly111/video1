import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/video_task.dart';
import '../services/bitrate_advisor.dart';
import '../services/compression_queue_controller.dart';
import '../utils/format_utils.dart';
import 'result_comparison_screen.dart';

class QueueConfigScreen extends StatelessWidget {
  final CompressionQueueController controller;

  const QueueConfigScreen({super.key, required this.controller});

  Future<void> _addMoreVideos(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: true,
    );
    if (result != null && result.paths.isNotEmpty) {
      await controller.importVideoPaths(result.paths.whereType<String>().toList());
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final tasks = controller.tasks;
        return Scaffold(
          backgroundColor: const Color(0xFF0B0F19),
          appBar: AppBar(
            backgroundColor: const Color(0xFF0B0F19),
            title: const Text(
              '任务配置与串行队列',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            ),
            actions: [
              IconButton(
                tooltip: '继续添加视频',
                onPressed: () => _addMoreVideos(context),
                icon: const Icon(Icons.add_circle_outline_rounded,
                    color: Color(0xFF06B6D4)),
              ),
              if (tasks.any((t) =>
                  t.status == TaskStatus.completed ||
                  t.status == TaskStatus.skipped ||
                  t.status == TaskStatus.cancelled))
                IconButton(
                  tooltip: '清理已完成项',
                  onPressed: controller.clearCompletedTasks,
                  icon: const Icon(Icons.cleaning_services_rounded,
                      color: Colors.white70),
                ),
            ],
          ),
          body: Column(
            children: [
              _buildPresetAndCustomConfigBar(context),
              Expanded(
                child: tasks.isEmpty
                    ? const Center(
                        child: Text(
                          '队列为空，请点击右上角添加待压缩视频',
                          style: TextStyle(color: Colors.white54),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                        itemCount: tasks.length,
                        itemBuilder: (context, idx) =>
                            _buildTaskQueueCard(context, tasks[idx]),
                      ),
              ),
            ],
          ),
          bottomNavigationBar: _buildBottomBatchBar(context),
        );
      },
    );
  }

  Widget _buildPresetAndCustomConfigBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
      decoration: const BoxDecoration(
        color: Color(0xFF111827),
        border: Border(bottom: BorderSide(color: Color(0xFF1F2937))),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: CompressionPreset.values.map((p) {
                final selected = controller.preset == p;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(BitrateAdvisor.presetTitle(p)),
                    selected: selected,
                    onSelected: controller.isProcessingQueue
                        ? null
                        : (_) => controller.updatePreset(p),
                    selectedColor: const Color(0xFF06B6D4),
                    backgroundColor: const Color(0xFF1F2937),
                    labelStyle: TextStyle(
                      color: selected ? Colors.black : Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 12.5,
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          if (controller.preset == CompressionPreset.custom) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('分辨率: ',
                    style: TextStyle(color: Colors.white70, fontSize: 12.5)),
                DropdownButton<CustomResolutionCap>(
                  value: controller.customResolutionCap,
                  dropdownColor: const Color(0xFF1F2937),
                  style: const TextStyle(color: Colors.white, fontSize: 12.5),
                  onChanged: controller.isProcessingQueue
                      ? null
                      : (val) =>
                          controller.updateCustomSettings(resolutionCap: val),
                  items: const [
                    DropdownMenuItem(
                      value: CustomResolutionCap.original,
                      child: Text('原画分辨率'),
                    ),
                    DropdownMenuItem(
                      value: CustomResolutionCap.uhd2k,
                      child: Text('2K (1440p)'),
                    ),
                    DropdownMenuItem(
                      value: CustomResolutionCap.fhd1080p,
                      child: Text('1080p Full HD'),
                    ),
                    DropdownMenuItem(
                      value: CustomResolutionCap.hd720p,
                      child: Text('720p HD'),
                    ),
                  ],
                ),
                const Spacer(),
                const Text('编码: ',
                    style: TextStyle(color: Colors.white70, fontSize: 12.5)),
                SegmentedButton<VideoCodecOption>(
                  segments: const [
                    ButtonSegment(
                      value: VideoCodecOption.hevc,
                      label: Text('HEVC', style: TextStyle(fontSize: 11)),
                    ),
                    ButtonSegment(
                      value: VideoCodecOption.h264,
                      label: Text('H.264', style: TextStyle(fontSize: 11)),
                    ),
                  ],
                  selected: {controller.customCodec},
                  onSelectionChanged: controller.isProcessingQueue
                      ? null
                      : (set) =>
                          controller.updateCustomSettings(codec: set.first),
                ),
              ],
            ),
            Row(
              children: [
                Text(
                  '目标码率: ${controller.customBitrateMbps.toStringAsFixed(1)} Mbps',
                  style: const TextStyle(color: Colors.white70, fontSize: 12.5),
                ),
                Expanded(
                  child: Slider(
                    value: controller.customBitrateMbps,
                    min: 0.5,
                    max: 25.0,
                    divisions: 49,
                    activeColor: const Color(0xFF06B6D4),
                    onChanged: controller.isProcessingQueue
                        ? null
                        : (v) =>
                            controller.updateCustomSettings(bitrateMbps: v),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.volume_up_rounded,
                  color: Color(0xFF38BDF8), size: 16),
              const SizedBox(width: 6),
              const Text(
                '音轨无损直通 (Passthrough)',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              Switch(
                value: controller.audioPassthrough,
                activeThumbColor: const Color(0xFF06B6D4),
                onChanged: controller.isProcessingQueue
                    ? null
                    : controller.setAudioPassthrough,
              ),
              const Spacer(),
              const Text(
                '智能跳过低码率',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              Switch(
                value: controller.autoSkipHighlyCompressed,
                activeThumbColor: const Color(0xFF10B981),
                onChanged: controller.isProcessingQueue
                    ? null
                    : controller.setAutoSkipHighlyCompressed,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTaskQueueCard(BuildContext context, VideoCompressionTask task) {
    final advice = task.advice;
    final estReductionPct =
        ((1.0 - advice.estimatedCompressionRatio) * 100).clamp(0.0, 95.0);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF131C31),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: task.status == TaskStatus.running
              ? const Color(0xFF06B6D4)
              : const Color(0xFF1F2937),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  task.source.fileName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
              ),
              _buildStatusBadge(task.status),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              _buildInfoChip(
                '原片 ${task.source.resolutionLabel} · ${FormatUtils.formatBytes(task.source.sizeBytes)}',
                Colors.white70,
              ),
              _buildInfoChip(
                '目标 ${advice.targetResolutionLabel} · ${advice.preferHevc ? "H.265" : "H.264"}',
                const Color(0xFF38BDF8),
              ),
              _buildInfoChip(
                '预估 ${FormatUtils.formatBytes(advice.estimatedSizeBytes)} (-${estReductionPct.toStringAsFixed(0)}%)',
                const Color(0xFF34D399),
              ),
            ],
          ),
          if (advice.shouldSkip) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF78350F).withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFF59E0B)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline_rounded,
                      color: Color(0xFFFBBF24), size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '${advice.skipReason}（原码率 ${FormatUtils.formatBitrate(task.source.bitrateBps)} < 目标码率 1.1x）',
                      style: const TextStyle(
                        color: Color(0xFFFDE68A),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (task.status == TaskStatus.running) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: task.progress,
                minHeight: 8,
                backgroundColor: const Color(0xFF1F2937),
                valueColor:
                    const AlwaysStoppedAnimation<Color>(Color(0xFF06B6D4)),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  '${(task.progress * 100).toStringAsFixed(1)}%',
                  style: const TextStyle(
                    color: Color(0xFF06B6D4),
                    fontWeight: FontWeight.w700,
                    fontSize: 12.5,
                  ),
                ),
                const SizedBox(width: 14),
                Text(
                  '处理速度: ${task.currentFps.toStringAsFixed(1)} fps',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const Spacer(),
                Text(
                  FormatUtils.formatEtaSeconds(task.etaSeconds),
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () => controller.cancelTask(task.id),
                  icon: const Icon(Icons.cancel_outlined,
                      color: Colors.redAccent, size: 16),
                  label: const Text(
                    '取消',
                    style: TextStyle(color: Colors.redAccent, fontSize: 12),
                  ),
                ),
              ],
            ),
          ],
          if (task.status == TaskStatus.completed && task.result != null) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Text(
                  '实测压缩后: ${FormatUtils.formatBytes(task.result!.outputSizeBytes)} · 均速 ${task.result!.averageFps.toStringAsFixed(1)} fps',
                  style: const TextStyle(
                    color: Color(0xFF34D399),
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF06B6D4),
                    foregroundColor: Colors.black,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  ),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ResultComparisonScreen(
                          controller: controller,
                          task: task,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.compare_rounded, size: 16),
                  label: const Text(
                    '效果对比',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                  ),
                ),
              ],
            ),
          ],
          if (task.status == TaskStatus.failed && task.errorMessage != null) ...[
            const SizedBox(height: 8),
            Text(
              '错误: ${task.errorMessage}',
              style: const TextStyle(color: Colors.redAccent, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.28),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(color: color, fontSize: 11.5),
      ),
    );
  }

  Widget _buildStatusBadge(TaskStatus status) {
    final (String text, Color color) = switch (status) {
      TaskStatus.queued => ('待处理', Colors.white60),
      TaskStatus.running => ('硬编进行中', const Color(0xFF06B6D4)),
      TaskStatus.completed => ('已完成', const Color(0xFF34D399)),
      TaskStatus.skipped => ('智能跳过', const Color(0xFFFBBF24)),
      TaskStatus.cancelled => ('已取消', Colors.orangeAccent),
      TaskStatus.failed => ('失败', Colors.redAccent),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style:
            TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _buildBottomBatchBar(BuildContext context) {
    final queuedCount =
        controller.tasks.where((t) => t.status == TaskStatus.queued).length;
    final totalOrig = controller.totalOriginalBytes;
    final totalEst = controller.totalEstimatedCompressedBytes;

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      decoration: const BoxDecoration(
        color: Color(0xFF111827),
        border: Border(top: BorderSide(color: Color(0xFF1F2937))),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '总原片 ${FormatUtils.formatBytes(totalOrig)} → 预估 ${FormatUtils.formatBytes(totalEst)}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 2),
                const Text(
                  '后台串行队列执行 (并发数=1，保护硬件编码器)',
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
              ],
            ),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF06B6D4),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: (controller.isProcessingQueue || queuedCount == 0)
                ? null
                : controller.startSerialQueue,
            icon: Icon(
              controller.isProcessingQueue
                  ? Icons.hourglass_top_rounded
                  : Icons.play_arrow_rounded,
            ),
            label: Text(
              controller.isProcessingQueue
                  ? '串行压制中...'
                  : '开始压缩 ($queuedCount)',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}
