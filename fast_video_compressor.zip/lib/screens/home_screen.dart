import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/video_task.dart';
import '../services/bitrate_advisor.dart';
import '../services/compression_queue_controller.dart';
import '../utils/format_utils.dart';
import 'queue_config_screen.dart';
import 'result_comparison_screen.dart';

class HomeScreen extends StatefulWidget {
  final CompressionQueueController controller;

  const HomeScreen({super.key, required this.controller});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isPicking = false;

  Future<void> _pickVideosFromGallery() async {
    if (_isPicking) return;
    setState(() => _isPicking = true);
    try {
      if (Platform.isAndroid) {
        await [
          Permission.videos,
          Permission.storage,
        ].request();
      } else if (Platform.isIOS) {
        await Permission.photos.request();
      }

      final result = await FilePicker.platform.pickFiles(
        type: FileType.video,
        allowMultiple: true,
      );

      if (result != null && result.paths.isNotEmpty) {
        final validPaths = result.paths.whereType<String>().toList();
        await widget.controller.importVideoPaths(validPaths);
        if (mounted && validPaths.isNotEmpty) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => QueueConfigScreen(controller: widget.controller),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导入视频失败: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isPicking = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        final tasks = widget.controller.tasks;
        final completedTasks =
            tasks.where((t) => t.status == TaskStatus.completed).toList();

        return Scaffold(
          backgroundColor: const Color(0xFF0B0F19),
          appBar: AppBar(
            backgroundColor: const Color(0xFF0B0F19),
            elevation: 0,
            title: const Row(
              children: [
                Icon(Icons.bolt_rounded, color: Color(0xFF06B6D4), size: 28),
                SizedBox(width: 8),
                Text(
                  '极速硬件视频压缩',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            actions: [
              if (tasks.isNotEmpty)
                TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) =>
                            QueueConfigScreen(controller: widget.controller),
                      ),
                    );
                  },
                  icon: const Icon(Icons.playlist_play_rounded,
                      color: Color(0xFF06B6D4)),
                  label: Text(
                    '队列 (${tasks.length})',
                    style: const TextStyle(color: Color(0xFF06B6D4)),
                  ),
                ),
            ],
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              children: [
                _buildSavedStorageHeroCard(),
                const SizedBox(height: 20),
                _buildHardwareArchitectureBadge(),
                const SizedBox(height: 24),
                _buildImportActionCard(),
                const SizedBox(height: 28),
                _buildPresetOverviewSection(),
                if (completedTasks.isNotEmpty) ...[
                  const SizedBox(height: 28),
                  const Text(
                    '最近压缩完成（点击查看画质对比）',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ...completedTasks.reversed.take(5).map(_buildCompletedItemTile),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSavedStorageHeroCard() {
    final savedBytes = widget.controller.cumulativeSavedBytes;
    final count = widget.controller.cumulativeCompressedCount;

    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF1E1B4B), Color(0xFF0F766E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF06B6D4).withValues(alpha: 0.18),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Text(
                  '累计已节省手机存储空间',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              const Spacer(),
              const Icon(Icons.AutoAwesome_rounded,
                  color: Color(0xFF38BDF8), size: 20),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            FormatUtils.formatBytes(savedBytes),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 38,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildMetricPill(
                icon: Icons.video_Call_rounded,
                label: '已压制 $count 个视频',
              ),
              const SizedBox(width: 10),
              _buildMetricPill(
                icon: Icons.memory_rounded,
                label: 'GPU 零拷贝硬编',
              ),
              const SizedBox(width: 10),
              _buildMetricPill(
                icon: Icons.graphic_eq_rounded,
                label: '音轨无损直通',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMetricPill({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.25),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: const Color(0xFF38BDF8), size: 14),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHardwareArchitectureBadge() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1F2937)),
      ),
      child: const Row(
        children: [
          Icon(Icons.speed_rounded, color: Color(0xFF10B981), size: 24),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'MediaCodec / VideoToolbox 原生硬解硬编 + OpenGL ES 零拷贝缩放，速度比传统 FFmpeg 软编快 5~10 倍且机身不发烫。',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12.5,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImportActionCard() {
    return GestureDetector(
      onTap: _pickVideosFromGallery,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 34, horizontal: 24),
        decoration: BoxDecoration(
          color: const Color(0xFF131C31),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: const Color(0xFF06B6D4).withValues(alpha: 0.5),
            width: 1.6,
          ),
        ),
        child: Column(
          children: [
            Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(
                color: const Color(0xFF06B6D4).withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: _isPicking
                  ? const Padding(
                      padding: EdgeInsets.all(18),
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        color: Color(0xFF06B6D4),
                      ),
                    )
                  : const Icon(
                      Icons.video_library_rounded,
                      color: Color(0xFF06B6D4),
                      size: 34,
                    ),
            ),
            const SizedBox(height: 16),
            const Text(
              '从系统相册批量导入视频',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              '支持多选 4K/60fps 大体积视频 · 自动识别竖屏旋转与低码率原片',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white54,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPresetOverviewSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'BPP 自适应码率引擎档位',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        ...CompressionPreset.values.map((preset) {
          final isSelected = widget.controller.preset == preset;
          return GestureDetector(
            onTap: () => widget.controller.updatePreset(preset),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: isSelected
                    ? const Color(0xFF162544)
                    : const Color(0xFF111827),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isSelected
                      ? const Color(0xFF06B6D4)
                      : const Color(0xFF1F2937),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    isSelected
                        ? Icons.radio_button_checked_rounded
                        : Icons.radio_button_off_rounded,
                    color: isSelected
                        ? const Color(0xFF06B6D4)
                        : Colors.white38,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          BitrateAdvisor.presetTitle(preset),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 14.5,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          BitrateAdvisor.presetSubtitle(preset),
                          style: const TextStyle(
                            color: Colors.white60,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildCompletedItemTile(VideoCompressionTask task) {
    final res = task.result!;
    final ratioPct = ((1.0 - (res.outputSizeBytes / task.source.sizeBytes)) * 100)
        .clamp(0.0, 99.0);
    return Card(
      color: const Color(0xFF111827),
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ResultComparisonScreen(
                controller: widget.controller,
                task: task,
              ),
            ),
          );
        },
        leading: const CircleAvatar(
          backgroundColor: Color(0xFF065F46),
          child: Icon(Icons.check_rounded, color: Colors.white),
        ),
        title: Text(
          task.source.fileName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          '${FormatUtils.formatBytes(task.source.sizeBytes)} → ${FormatUtils.formatBytes(res.outputSizeBytes)} (缩减 ${ratioPct.toStringAsFixed(0)}%)',
          style: const TextStyle(color: Color(0xFF34D399), fontSize: 12.5),
        ),
        trailing: const Icon(Icons.compare_rounded, color: Colors.white70),
      ),
    );
  }
}
