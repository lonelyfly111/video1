class FormatUtils {
  static String formatBytes(int bytes) {
    if (bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    double val = bytes.toDouble();
    int unitIndex = 0;
    while (val >= 1024 && unitIndex < units.length - 1) {
      val /= 1024;
      unitIndex++;
    }
    return '${val.toStringAsFixed(unitIndex >= 2 ? 2 : 1)} ${units[unitIndex]}';
  }

  static String formatBitrate(int bps) {
    if (bps <= 0) return '0 kbps';
    if (bps >= 1000000) {
      return '${(bps / 1000000.0).toStringAsFixed(2)} Mbps';
    }
    return '${(bps / 1000.0).toStringAsFixed(0)} kbps';
  }

  static String formatDurationMs(int durationMs) {
    final totalSeconds = (durationMs / 1000).round();
    final mins = totalSeconds ~/ 60;
    final secs = totalSeconds % 60;
    return '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  static String formatEtaSeconds(int seconds) {
    if (seconds <= 0) return '即将完成';
    if (seconds < 60) return '剩余 ${seconds}s';
    final mins = seconds ~/ 60;
    final secs = seconds % 60;
    return '剩余 ${mins}m ${secs}s';
  }
}
