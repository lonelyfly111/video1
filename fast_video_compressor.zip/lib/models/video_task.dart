enum CompressionPreset {
  socialFast, // 档位 1「极速社交分享」：最高限制 720p，K = 0.05
  hdBalanced, // 档位 2「高清均衡（默认）」：保持原分辨率（最高 1080p/2K），H.265，K = 0.07
  originalArchive, // 档位 3「原画级存档」：保持原分辨率（支持 4K），H.265，K = 0.11
  custom, // 档位 4「自定义参数」：支持手动选择分辨率、编码格式与码率滑块
}

enum CustomResolutionCap {
  original,
  uhd2k, // 1440p
  fhd1080p, // 1080p
  hd720p, // 720p
}

enum VideoCodecOption {
  hevc, // H.265 / HEVC (优先硬编)
  h264, // H.264 / AVC (高兼容)
}

enum TaskStatus {
  queued,
  running,
  completed,
  skipped,
  cancelled,
  failed,
}

class VideoMetadata {
  final String path;
  final String fileName;
  final int width;
  final int height;
  final int rotation;
  final int durationMs;
  final int bitrateBps;
  final double fps;
  final int sizeBytes;
  final bool hasAudio;
  final String videoCodec;

  const VideoMetadata({
    required this.path,
    required this.fileName,
    required this.width,
    required this.height,
    required this.rotation,
    required this.durationMs,
    required this.bitrateBps,
    required this.fps,
    required this.sizeBytes,
    required this.hasAudio,
    required this.videoCodec,
  });

  int get displayWidth => (rotation == 90 || rotation == 270) ? height : width;
  int get displayHeight => (rotation == 90 || rotation == 270) ? width : height;

  String get resolutionLabel => '${displayWidth}x$displayHeight';
}

class BitrateAdvice {
  final int targetWidth;
  final int targetHeight;
  final int targetFps;
  final int targetBitrateBps;
  final int estimatedSizeBytes;
  final double estimatedCompressionRatio;
  final bool preferHevc;
  final bool shouldSkip;
  final String skipReason;
  final double bppFactorK;

  const BitrateAdvice({
    required this.targetWidth,
    required this.targetHeight,
    required this.targetFps,
    required this.targetBitrateBps,
    required this.estimatedSizeBytes,
    required this.estimatedCompressionRatio,
    required this.preferHevc,
    required this.shouldSkip,
    required this.skipReason,
    required this.bppFactorK,
  });

  String get targetResolutionLabel => '${targetWidth}x$targetHeight';
}

class CompressionResult {
  final String outputPath;
  final int outputSizeBytes;
  final int outputWidth;
  final int outputHeight;
  final int outputBitrateBps;
  final String codecUsed;
  final double averageFps;
  final int elapsedMs;
  final bool savedToGallery;
  final bool originalDeleted;

  const CompressionResult({
    required this.outputPath,
    required this.outputSizeBytes,
    required this.outputWidth,
    required this.outputHeight,
    required this.outputBitrateBps,
    required this.codecUsed,
    required this.averageFps,
    required this.elapsedMs,
    this.savedToGallery = false,
    this.originalDeleted = false,
  });

  CompressionResult copyWith({
    bool? savedToGallery,
    bool? originalDeleted,
  }) {
    return CompressionResult(
      outputPath: outputPath,
      outputSizeBytes: outputSizeBytes,
      outputWidth: outputWidth,
      outputHeight: outputHeight,
      outputBitrateBps: outputBitrateBps,
      codecUsed: codecUsed,
      averageFps: averageFps,
      elapsedMs: elapsedMs,
      savedToGallery: savedToGallery ?? this.savedToGallery,
      originalDeleted: originalDeleted ?? this.originalDeleted,
    );
  }
}

class VideoCompressionTask {
  final String id;
  final VideoMetadata source;
  BitrateAdvice advice;
  TaskStatus status;
  double progress;
  double currentFps;
  int etaSeconds;
  String? errorMessage;
  CompressionResult? result;

  VideoCompressionTask({
    required this.id,
    required this.source,
    required this.advice,
    this.status = TaskStatus.queued,
    this.progress = 0.0,
    this.currentFps = 0.0,
    this.etaSeconds = 0,
    this.errorMessage,
    this.result,
  });

  int get savedBytes {
    final res = result;
    if (res == null) return 0;
    final diff = source.sizeBytes - res.outputSizeBytes;
    return diff > 0 ? diff : 0;
  }
}
