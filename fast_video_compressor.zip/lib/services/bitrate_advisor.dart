import 'dart:math' as math;
import '../models/video_task.dart';

/// BPP (Bits Per Pixel) 自适应码率与智能跳过引擎
///
/// 核心公式：
/// `TargetBitrate = TargetWidth * TargetHeight * TargetFPS * K`
///
/// - 档位 1「极速社交分享」：最高限制 720p，`K = 0.05`
/// - 档位 2「高清均衡（默认）」：保持原分辨率（最高 1080p/2K），H.265，`K = 0.07`
/// - 档位 3「原画级存档」：保持原分辨率（支持 4K），H.265，`K = 0.11`
/// - 档位 4「自定义参数」：支持手动选择分辨率（原画/2K/1080p/720p）、编码格式（HEVC/H.264）与码率滑块
/// - 智能跳过判定：若原视频平均码率已低于目标码率的 1.1 倍，标记 `shouldSkip = true`，
///   在 UI 上提示“原视频已高度压缩，建议保留原片”。
class BitrateAdvisor {
  static const double kSocialFast = 0.05;
  static const double kHdBalanced = 0.07;
  static const double kOriginalArchive = 0.11;

  static BitrateAdvice evaluate({
    required VideoMetadata metadata,
    required CompressionPreset preset,
    CustomResolutionCap customResolutionCap = CustomResolutionCap.fhd1080p,
    VideoCodecOption customCodec = VideoCodecOption.hevc,
    double customBitrateMbps = 3.5,
  }) {
    final int srcW = math.max(2, metadata.width);
    final int srcH = math.max(2, metadata.height);
    final int targetFps = metadata.fps > 0
        ? metadata.fps.round().clamp(15, 60)
        : 30;

    int maxShortEdge;
    double kFactor;
    bool preferHevc;

    switch (preset) {
      case CompressionPreset.socialFast:
        maxShortEdge = 720;
        kFactor = kSocialFast;
        preferHevc = false; // Social sharing prioritizes universal H.264/HEVC compatibility
        break;
      case CompressionPreset.hdBalanced:
        maxShortEdge = 1440; // Supports 1080p / 2K (1440p) cap
        kFactor = kHdBalanced;
        preferHevc = true; // H.265 hardware encoding by default
        break;
      case CompressionPreset.originalArchive:
        maxShortEdge = 2160; // Preserves original resolution up to 4K UHD
        kFactor = kOriginalArchive;
        preferHevc = true; // H.265 hardware encoding
        break;
      case CompressionPreset.custom:
        maxShortEdge = _shortEdgeForCustomCap(customResolutionCap, srcW, srcH);
        preferHevc = customCodec == VideoCodecOption.hevc;
        kFactor = kHdBalanced;
        break;
    }

    final scaledDims = _computeEvenDimensions(
      srcW: srcW,
      srcH: srcH,
      maxShortEdge: maxShortEdge,
    );
    final int targetWidth = scaledDims.$1;
    final int targetHeight = scaledDims.$2;

    final int targetBitrateBps;
    if (preset == CompressionPreset.custom) {
      targetBitrateBps = (customBitrateMbps * 1000000).round().clamp(250000, 60000000);
      kFactor = targetBitrateBps / (targetWidth * targetHeight * targetFps);
    } else {
      // Exact formula: TargetBitrate = TargetWidth * TargetHeight * TargetFPS * K
      targetBitrateBps = (targetWidth * targetHeight * targetFps * kFactor).round();
    }

    // Smart Skip Detection: If original video average bitrate is already below 1.1x target bitrate
    final bool shouldSkip = metadata.bitrateBps > 0 &&
        metadata.bitrateBps < (targetBitrateBps * 1.1).round();

    // Estimate audio passthrough overhead (~128 kbps if source has audio)
    final int audioBitrateEstimate = metadata.hasAudio ? 128000 : 0;
    final double durationSec = math.max(0.5, metadata.durationMs / 1000.0);
    final int rawEstimatedBytes =
        (((targetBitrateBps + audioBitrateEstimate) * durationSec) / 8.0).round();
    final int estimatedSizeBytes = shouldSkip
        ? metadata.sizeBytes
        : math.min(metadata.sizeBytes, math.max(1024, rawEstimatedBytes));

    final double ratio = metadata.sizeBytes > 0
        ? (estimatedSizeBytes / metadata.sizeBytes).clamp(0.05, 1.0)
        : 1.0;

    return BitrateAdvice(
      targetWidth: targetWidth,
      targetHeight: targetHeight,
      targetFps: targetFps,
      targetBitrateBps: targetBitrateBps,
      estimatedSizeBytes: estimatedSizeBytes,
      estimatedCompressionRatio: ratio,
      preferHevc: preferHevc,
      shouldSkip: shouldSkip,
      skipReason: shouldSkip ? '原视频已高度压缩，建议保留原片' : '',
      bppFactorK: kFactor,
    );
  }

  static int _shortEdgeForCustomCap(
    CustomResolutionCap cap,
    int srcW,
    int srcH,
  ) {
    final int srcShort = math.min(srcW, srcH);
    switch (cap) {
      case CustomResolutionCap.original:
        return srcShort;
      case CustomResolutionCap.uhd2k:
        return 1440;
      case CustomResolutionCap.fhd1080p:
        return 1080;
      case CustomResolutionCap.hd720p:
        return 720;
    }
  }

  /// Computes aspect-ratio-preserving dimensions aligned to even integers (bitwise `& ~1`)
  /// so hardware H.264/HEVC encoders never fail on odd macroblock boundaries.
  static (int, int) _computeEvenDimensions({
    required int srcW,
    required int srcH,
    required int maxShortEdge,
  }) {
    final int shortEdge = math.min(srcW, srcH);
    if (shortEdge <= maxShortEdge) {
      return (math.max(2, srcW & ~1), math.max(2, srcH & ~1));
    }
    final double scale = maxShortEdge / shortEdge;
    final int scaledW = math.max(2, (srcW * scale).round() & ~1);
    final int scaledH = math.max(2, (srcH * scale).round() & ~1);
    return (scaledW, scaledH);
  }

  static String presetTitle(CompressionPreset preset) {
    switch (preset) {
      case CompressionPreset.socialFast:
        return '极速社交分享';
      case CompressionPreset.hdBalanced:
        return '高清均衡（默认）';
      case CompressionPreset.originalArchive:
        return '原画级存档';
      case CompressionPreset.custom:
        return '自定义参数';
    }
  }

  static String presetSubtitle(CompressionPreset preset) {
    switch (preset) {
      case CompressionPreset.socialFast:
        return '最高限制 720p · K=0.05 · 微信/社交秒发';
      case CompressionPreset.hdBalanced:
        return '保持 1080p/2K · H.265 硬编 · K=0.07';
      case CompressionPreset.originalArchive:
        return '保留 4K 原分辨率 · H.265 硬编 · K=0.11';
      case CompressionPreset.custom:
        return '自由调节分辨率、HEVC/H.264 与目标码率';
    }
  }
}
