import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/video_task.dart';
import 'bitrate_advisor.dart';
import 'native_compressor_bridge.dart';

/// Manages the batch video compression queue with strict serial execution (concurrency = 1)
/// to protect the SoC hardware MediaCodec / VideoToolbox instance from resource exhaustion.
class CompressionQueueController extends ChangeNotifier {
  static const String _prefSavedBytesKey = 'cumulative_saved_bytes_v1';
  static const String _prefCompletedCountKey = 'cumulative_completed_videos_v1';

  final NativeCompressorBridge _bridge;
  final List<VideoCompressionTask> _tasks = [];
  StreamSubscription<NativeProgressEvent>? _eventSub;

  CompressionPreset _preset = CompressionPreset.hdBalanced;
  CustomResolutionCap _customResolutionCap = CustomResolutionCap.fhd1080p;
  VideoCodecOption _customCodec = VideoCodecOption.hevc;
  double _customBitrateMbps = 3.5;
  bool _audioPassthrough = true;
  bool _autoSkipHighlyCompressed = true;

  bool _isProcessingQueue = false;
  int _cumulativeSavedBytes = 0;
  int _cumulativeCompressedCount = 0;

  CompressionQueueController({NativeCompressorBridge? bridge})
      : _bridge = bridge ?? NativeCompressorBridge() {
    _init();
  }

  List<VideoCompressionTask> get tasks => List.unmodifiable(_tasks);
  CompressionPreset get preset => _preset;
  CustomResolutionCap get customResolutionCap => _customResolutionCap;
  VideoCodecOption get customCodec => _customCodec;
  double get customBitrateMbps => _customBitrateMbps;
  bool get audioPassthrough => _audioPassthrough;
  bool get autoSkipHighlyCompressed => _autoSkipHighlyCompressed;
  bool get isProcessingQueue => _isProcessingQueue;
  int get cumulativeSavedBytes => _cumulativeSavedBytes;
  int get cumulativeCompressedCount => _cumulativeCompressedCount;

  int get totalOriginalBytes =>
      _tasks.fold(0, (sum, item) => sum + item.source.sizeBytes);

  int get totalEstimatedCompressedBytes =>
      _tasks.fold(0, (sum, item) => sum + item.advice.estimatedSizeBytes);

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    _cumulativeSavedBytes = prefs.getInt(_prefSavedBytesKey) ?? 0;
    _cumulativeCompressedCount = prefs.getInt(_prefCompletedCountKey) ?? 0;

    _eventSub = _bridge.progressStream.listen((event) {
      final index = _tasks.indexWhere((t) => t.id == event.taskId);
      if (index < 0) return;
      final task = _tasks[index];
      task.progress = event.progress.clamp(0.0, 1.0);
      task.currentFps = event.fps;
      task.etaSeconds = event.etaSeconds;
      if (event.status == 'cancelled') {
        task.status = TaskStatus.cancelled;
      } else if (event.status == 'failed') {
        task.status = TaskStatus.failed;
        task.errorMessage = event.error;
      }
      notifyListeners();
    });
    notifyListeners();
  }

  Future<void> importVideoPaths(List<String> paths) async {
    for (final path in paths) {
      if (path.isEmpty) continue;
      if (_tasks.any((t) => t.source.path == path && t.status != TaskStatus.completed)) {
        continue;
      }
      try {
        final meta = await _bridge.getVideoMetadata(path);
        final advice = BitrateAdvisor.evaluate(
          metadata: meta,
          preset: _preset,
          customResolutionCap: _customResolutionCap,
          customCodec: _customCodec,
          customBitrateMbps: _customBitrateMbps,
        );
        final task = VideoCompressionTask(
          id: '${DateTime.now().microsecondsSinceEpoch}_${_tasks.length}',
          source: meta,
          advice: advice,
        );
        _tasks.add(task);
      } catch (e) {
        debugPrint('Failed to inspect video $path: $e');
      }
    }
    notifyListeners();
  }

  void updatePreset(CompressionPreset newPreset) {
    _preset = newPreset;
    _recalculateAllQueuedAdvice();
  }

  void updateCustomSettings({
    CustomResolutionCap? resolutionCap,
    VideoCodecOption? codec,
    double? bitrateMbps,
  }) {
    if (resolutionCap != null) _customResolutionCap = resolutionCap;
    if (codec != null) _customCodec = codec;
    if (bitrateMbps != null) _customBitrateMbps = bitrateMbps;
    _recalculateAllQueuedAdvice();
  }

  void setAudioPassthrough(bool enabled) {
    _audioPassthrough = enabled;
    notifyListeners();
  }

  void setAutoSkipHighlyCompressed(bool enabled) {
    _autoSkipHighlyCompressed = enabled;
    notifyListeners();
  }

  void _recalculateAllQueuedAdvice() {
    for (final task in _tasks) {
      if (task.status == TaskStatus.queued || task.status == TaskStatus.skipped) {
        task.advice = BitrateAdvisor.evaluate(
          metadata: task.source,
          preset: _preset,
          customResolutionCap: _customResolutionCap,
          customCodec: _customCodec,
          customBitrateMbps: _customBitrateMbps,
        );
        if (task.status == TaskStatus.skipped) {
          task.status = TaskStatus.queued;
        }
      }
    }
    notifyListeners();
  }

  /// Starts executing queued tasks strictly one-by-one (concurrency = 1).
  Future<void> startSerialQueue() async {
    if (_isProcessingQueue) return;
    _isProcessingQueue = true;
    notifyListeners();

    try {
      final tempDir = await getTemporaryDirectory();
      final outFolder = Directory('${tempDir.path}/compressed_outputs');
      if (!outFolder.existsSync()) {
        outFolder.createSync(recursive: true);
      }

      while (true) {
        VideoCompressionTask? nextTask;
        for (final t in _tasks) {
          if (t.status == TaskStatus.queued) {
            nextTask = t;
            break;
          }
        }
        if (nextTask == null) break;

        if (_autoSkipHighlyCompressed && nextTask.advice.shouldSkip) {
          nextTask.status = TaskStatus.skipped;
          nextTask.progress = 1.0;
          notifyListeners();
          continue;
        }

        nextTask.status = TaskStatus.running;
        nextTask.progress = 0.01;
        nextTask.errorMessage = null;
        notifyListeners();

        final outPath =
            '${outFolder.path}/fast_${nextTask.id}_${nextTask.source.fileName.replaceAll(' ', '_')}';

        try {
          final result = await _bridge.compressVideo(
            taskId: nextTask.id,
            inputPath: nextTask.source.path,
            outputPath: outPath,
            advice: nextTask.advice,
            audioPassthrough: _audioPassthrough,
          );
          nextTask.result = result;
          nextTask.progress = 1.0;
          nextTask.status = TaskStatus.completed;

          final saved = nextTask.savedBytes;
          if (saved > 0) {
            await _recordSavedSpace(saved);
          }
        } on PlatformException catch (e) {
          if (e.code == 'CANCELLED' || nextTask.status == TaskStatus.cancelled) {
            nextTask.status = TaskStatus.cancelled;
            nextTask.progress = 0.0;
          } else {
            nextTask.status = TaskStatus.failed;
            nextTask.errorMessage = e.message ?? '硬件编码异常中断';
          }
        } catch (e) {
          nextTask.status = TaskStatus.failed;
          nextTask.errorMessage = e.toString();
        }
        notifyListeners();
      }
    } finally {
      _isProcessingQueue = false;
      notifyListeners();
    }
  }

  Future<void> cancelTask(String taskId) async {
    final idx = _tasks.indexWhere((t) => t.id == taskId);
    if (idx < 0) return;
    final task = _tasks[idx];
    if (task.status == TaskStatus.queued) {
      task.status = TaskStatus.cancelled;
      notifyListeners();
    } else if (task.status == TaskStatus.running) {
      await _bridge.cancelTask(taskId);
      task.status = TaskStatus.cancelled;
      notifyListeners();
    }
  }

  void removeTask(String taskId) {
    _tasks.removeWhere((t) => t.id == taskId && t.status != TaskStatus.running);
    notifyListeners();
  }

  void clearCompletedTasks() {
    _tasks.removeWhere(
      (t) =>
          t.status == TaskStatus.completed ||
          t.status == TaskStatus.skipped ||
          t.status == TaskStatus.cancelled,
    );
    notifyListeners();
  }

  Future<String> saveResultToGallery(VideoCompressionTask task) async {
    final res = task.result;
    if (res == null) throw StateError('该任务尚未生成压缩结果文件');
    final savedUri = await _bridge.saveToGallery(res.outputPath);
    task.result = res.copyWith(savedToGallery: true);
    notifyListeners();
    return savedUri;
  }

  Future<bool> deleteOriginalFile(VideoCompressionTask task) async {
    final res = task.result;
    final ok = await _bridge.deleteOriginalVideo(task.source.path);
    if (ok && res != null) {
      task.result = res.copyWith(originalDeleted: true);
      notifyListeners();
    }
    return ok;
  }

  Future<void> _recordSavedSpace(int deltaBytes) async {
    _cumulativeSavedBytes += deltaBytes;
    _cumulativeCompressedCount += 1;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefSavedBytesKey, _cumulativeSavedBytes);
    await prefs.setInt(_prefCompletedCountKey, _cumulativeCompressedCount);
  }

  @override
  void dispose() {
    _eventSub?.cancel();
    super.dispose();
  }
}
