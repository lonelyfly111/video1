import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import '../models/video_task.dart';

class NativeProgressEvent {
  final String taskId;
  final double progress;
  final double fps;
  final int etaSeconds;
  final String status;
  final String? error;

  const NativeProgressEvent({
    required this.taskId,
    required this.progress,
    required this.fps,
    required this.etaSeconds,
    required this.status,
    this.error,
  });

  factory NativeProgressEvent.fromMap(Map<dynamic, dynamic> map) {
    return NativeProgressEvent(
      taskId: (map['taskId'] ?? '').toString(),
      progress: (map['progress'] as num?)?.toDouble() ?? 0.0,
      fps: (map['fps'] as num?)?.toDouble() ?? 0.0,
      etaSeconds: (map['etaSeconds'] as num?)?.toInt() ?? 0,
      status: (map['status'] ?? 'running').toString(),
      error: map['error']?.toString(),
    );
  }
}

class NativeCompressorBridge {
  static const MethodChannel _methodChannel =
      MethodChannel('com.example.fast_video_compressor/methods');
  static const EventChannel _eventChannel =
      EventChannel('com.example.fast_video_compressor/events');

  Stream<NativeProgressEvent>? _progressStream;

  Stream<NativeProgressEvent> get progressStream {
    _progressStream ??= _eventChannel
        .receiveBroadcastStream()
        .where((event) => event is Map)
        .map((event) => NativeProgressEvent.fromMap(event as Map));
    return _progressStream!;
  }

  Future<VideoMetadata> getVideoMetadata(String path) async {
    final fileName = path.split(Platform.pathSeparator).last;
    final raw = await _methodChannel.invokeMethod<Map<dynamic, dynamic>>(
      'getVideoMetadata',
      {'path': path},
    );
    if (raw == null) {
      throw PlatformException(
        code: 'NULL_METADATA',
        message: 'Native metadata extractor returned null for $path',
      );
    }

    return VideoMetadata(
      path: path,
      fileName: fileName,
      width: (raw['width'] as num?)?.toInt() ?? 1920,
      height: (raw['height'] as num?)?.toInt() ?? 1080,
      rotation: (raw['rotation'] as num?)?.toInt() ?? 0,
      durationMs: (raw['durationMs'] as num?)?.toInt() ?? 1000,
      bitrateBps: (raw['bitrateBps'] as num?)?.toInt() ?? 5000000,
      fps: (raw['fps'] as num?)?.toDouble() ?? 30.0,
      sizeBytes: (raw['sizeBytes'] as num?)?.toInt() ?? File(path).lengthSync(),
      hasAudio: (raw['hasAudio'] as bool?) ?? true,
      videoCodec: (raw['videoCodec'] ?? 'video/avc').toString(),
    );
  }

  Future<CompressionResult> compressVideo({
    required String taskId,
    required String inputPath,
    required String outputPath,
    required BitrateAdvice advice,
    bool audioPassthrough = true,
  }) async {
    final raw = await _methodChannel.invokeMethod<Map<dynamic, dynamic>>(
      'compressVideo',
      {
        'taskId': taskId,
        'inputPath': inputPath,
        'outputPath': outputPath,
        'targetWidth': advice.targetWidth,
        'targetHeight': advice.targetHeight,
        'targetBitrate': advice.targetBitrateBps,
        'targetFps': advice.targetFps,
        'preferHevc': advice.preferHevc,
        'audioPassthrough': audioPassthrough,
      },
    );

    if (raw == null) {
      throw PlatformException(
        code: 'EMPTY_RESULT',
        message: 'Hardware encoder returned empty result',
      );
    }

    return CompressionResult(
      outputPath: (raw['outputPath'] ?? outputPath).toString(),
      outputSizeBytes: (raw['outputSizeBytes'] as num?)?.toInt() ?? 0,
      outputWidth: (raw['outputWidth'] as num?)?.toInt() ?? advice.targetWidth,
      outputHeight: (raw['outputHeight'] as num?)?.toInt() ?? advice.targetHeight,
      outputBitrateBps:
          (raw['outputBitrate'] as num?)?.toInt() ?? advice.targetBitrateBps,
      codecUsed: (raw['codecUsed'] ?? (advice.preferHevc ? 'HEVC' : 'H.264')).toString(),
      averageFps: (raw['averageFps'] as num?)?.toDouble() ?? 0.0,
      elapsedMs: (raw['elapsedMs'] as num?)?.toInt() ?? 0,
    );
  }

  Future<void> cancelTask(String taskId) async {
    await _methodChannel.invokeMethod('cancelTask', {'taskId': taskId});
  }

  Future<String> saveToGallery(String path) async {
    final uri = await _methodChannel.invokeMethod<String>(
      'saveToGallery',
      {'path': path},
    );
    return uri ?? path;
  }

  Future<bool> deleteOriginalVideo(String path) async {
    final deleted = await _methodChannel.invokeMethod<bool>(
      'deleteOriginalVideo',
      {'path': path},
    );
    return deleted ?? false;
  }
}
