import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'services/compression_queue_controller.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const FastVideoCompressorApp());
}

class FastVideoCompressorApp extends StatefulWidget {
  const FastVideoCompressorApp({super.key});

  @override
  State<FastVideoCompressorApp> createState() => _FastVideoCompressorAppState();
}

class _FastVideoCompressorAppState extends State<FastVideoCompressorApp> {
  late final CompressionQueueController _controller;

  @override
  void initState() {
    super.initState();
    _controller = CompressionQueueController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '极速视频压缩',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0F19),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF06B6D4),
          brightness: Brightness.dark,
        ),
      ),
      home: HomeScreen(controller: _controller),
    );
  }
}
