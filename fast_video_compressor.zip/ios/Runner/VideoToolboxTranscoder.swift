import AVFoundation
import CoreMedia
import CoreVideo
import Foundation
import Photos
import VideoToolbox

final class TranscodeCancelToken {
    private let lock = NSLock()
    private var _isCancelled = false

    var isCancelled: Bool {
        lock.lock()
        defer { lock.unlock() }
        return _isCancelled
    }

    func cancel() {
        lock.lock()
        _isCancelled = true
        lock.unlock()
    }
}

final class VideoToolboxTranscoder {

    /// Extracts video track dimensions, transform rotation angle, bitrate, FPS, and audio presence.
    func inspectVideo(path: String) throws -> [String: Any] {
        let url = URL(fileURLWithPath: path)
        let asset = AVURLAsset(url: url, options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
        let fileSize = (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? NSNumber)?.int64Value ?? 0

        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            throw NSError(
                domain: "FastVideoCompressor",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "No video track found in file"]
            )
        }

        let naturalSize = videoTrack.naturalSize
        let transform = videoTrack.preferredTransform
        let rotation = Self.rotationDegrees(from: transform)
        let durationSeconds = CMTimeGetSeconds(asset.duration)
        let durationMs = Int64(max(0.0, durationSeconds * 1000.0))
        let nominalFps = Double(videoTrack.nominalFrameRate > 0 ? videoTrack.nominalFrameRate : 30.0)
        var bitrateBps = Int(videoTrack.estimatedDataRate)
        if bitrateBps <= 0 && durationSeconds > 0 {
            bitrateBps = Int((Double(fileSize) * 8.0) / durationSeconds)
        }

        let hasAudio = !asset.tracks(withMediaType: .audio).isEmpty
        return [
            "path": path,
            "width": Int(abs(naturalSize.width)),
            "height": Int(abs(naturalSize.height)),
            "rotation": rotation,
            "durationMs": durationMs,
            "bitrateBps": bitrateBps,
            "fps": nominalFps,
            "sizeBytes": fileSize,
            "hasAudio": hasAudio,
            "videoCodec": "avc1/hvc1"
        ]
    }

    /// Performs hardware-accelerated VideoToolbox transcoding via AVAssetReader + AVAssetWriter,
    /// preserving preferredTransform rotation matrix, color space attributes, and lossless audio passthrough.
    func transcode(
        taskId: String,
        inputPath: String,
        outputPath: String,
        targetWidth: Int,
        targetHeight: Int,
        targetBitrate: Int,
        targetFps: Int,
        preferHevc: Bool,
        audioPassthrough: Bool,
        cancelToken: TranscodeCancelToken,
        onProgress: @escaping ([String: Any]) -> Void,
        completion: @escaping (Result<[String: Any], Error>) -> Void
    ) {
        let inputURL = URL(fileURLWithPath: inputPath)
        let outputURL = URL(fileURLWithPath: outputPath)
        try? FileManager.default.removeItem(at: outputURL)

        let asset = AVURLAsset(url: inputURL, options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            completion(.failure(NSError(
                domain: "FastVideoCompressor",
                code: -2,
                userInfo: [NSLocalizedDescriptionKey: "Source file contains no video track"]
            )))
            return
        }

        let totalDurationSeconds = max(0.001, CMTimeGetSeconds(asset.duration))
        let alignedWidth = max(2, targetWidth & ~1)
        let alignedHeight = max(2, targetHeight & ~1)

        do {
            let reader = try AVAssetReader(asset: asset)
            let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
            writer.shouldOptimizeForNetworkUse = true

            // Decode to NV12 Bi-Planar hardware pixel buffer for zero-overhead VideoToolbox feeding
            let readerVideoSettings: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
            let videoOutput = AVAssetReaderTrackOutput(track: videoTrack, outputSettings: readerVideoSettings)
            videoOutput.alwaysCopiesSampleData = false
            if reader.canAdd(videoOutput) {
                reader.add(videoOutput)
            }

            let codecType: AVVideoCodecType = preferHevc ? .hevc : .h264
            var compressionProperties: [String: Any] = [
                AVVideoAverageBitRateKey: targetBitrate,
                AVVideoExpectedSourceFrameRateKey: targetFps,
                AVVideoMaxKeyFrameIntervalKey: targetFps * 2,
                AVVideoAllowFrameReorderingKey: true
            ]
            if preferHevc {
                compressionProperties[AVVideoProfileLevelKey] = kVTProfileLevel_HEVC_Main_AutoLevel
            } else {
                compressionProperties[AVVideoProfileLevelKey] = AVVideoProfileLevelH264HighAutoLevel
            }

            var writerVideoSettings: [String: Any] = [
                AVVideoCodecKey: codecType,
                AVVideoWidthKey: alignedWidth,
                AVVideoHeightKey: alignedHeight,
                AVVideoCompressionPropertiesKey: compressionProperties
            ]

            // Preserve source color space / HDR-to-SDR color properties when present
            if let formatDescriptions = videoTrack.formatDescriptions as? [CMFormatDescription],
               let formatDesc = formatDescriptions.first,
               let extensions = CMFormatDescriptionGetExtensions(formatDesc) as? [String: Any] {
                let colorPrimaries = extensions[kCMFormatDescriptionExtension_ColorPrimaries as String]
                let transferFunction = extensions[kCMFormatDescriptionExtension_TransferFunction as String]
                let ycbcrMatrix = extensions[kCMFormatDescriptionExtension_YCbCrMatrix as String]
                if let primaries = colorPrimaries, let transfer = transferFunction, let matrix = ycbcrMatrix {
                    writerVideoSettings[AVVideoColorPropertiesKey] = [
                        AVVideoColorPrimariesKey: primaries,
                        AVVideoTransferFunctionKey: transfer,
                        AVVideoYCbCrMatrixKey: matrix
                    ]
                }
            }

            let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: writerVideoSettings)
            videoInput.expectsMediaDataInRealTime = false
            // Preserve exact source preferredTransform rotation matrix
            videoInput.transform = videoTrack.preferredTransform
            if writer.canAdd(videoInput) {
                writer.add(videoInput)
            }

            // Configure Optional Lossless Audio Track Passthrough (nil outputSettings = direct bitstream copy)
            var audioOutput: AVAssetReaderTrackOutput?
            var audioInput: AVAssetWriterInput?
            if audioPassthrough, let audioTrack = asset.tracks(withMediaType: .audio).first {
                let aOut = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: nil)
                aOut.alwaysCopiesSampleData = false
                let aIn = AVAssetWriterInput(mediaType: .audio, outputSettings: nil)
                aIn.expectsMediaDataInRealTime = false
                if reader.canAdd(aOut) && writer.canAdd(aIn) {
                    reader.add(aOut)
                    writer.add(aIn)
                    audioOutput = aOut
                    audioInput = aIn
                }
            }

            guard reader.startReading() else {
                throw reader.error ?? NSError(
                    domain: "FastVideoCompressor",
                    code: -3,
                    userInfo: [NSLocalizedDescriptionKey: "AVAssetReader failed to start"]
                )
            }
            guard writer.startWriting() else {
                throw writer.error ?? NSError(
                    domain: "FastVideoCompressor",
                    code: -4,
                    userInfo: [NSLocalizedDescriptionKey: "AVAssetWriter failed to start"]
                )
            }
            writer.startSession(atSourceTime: .zero)

            let startTime = CFAbsoluteTimeGetCurrent()
            var encodedFrames = 0
            var lastProgressTime = 0.0

            let dispatchGroup = DispatchGroup()
            let videoQueue = DispatchQueue(label: "com.example.fast_video_compressor.videoQueue")
            let audioQueue = DispatchQueue(label: "com.example.fast_video_compressor.audioQueue")

            dispatchGroup.enter()
            videoInput.requestMediaDataWhenReady(on: videoQueue) {
                while videoInput.isReadyForMoreMediaData {
                    if cancelToken.isCancelled {
                        reader.cancelReading()
                        videoInput.markAsFinished()
                        dispatchGroup.leave()
                        return
                    }
                    if let sampleBuffer = videoOutput.copyNextSampleBuffer() {
                        let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
                        let ptsSeconds = CMTimeGetSeconds(pts)
                        videoInput.append(sampleBuffer)
                        encodedFrames += 1

                        let now = CFAbsoluteTimeGetCurrent()
                        if now - lastProgressTime >= 0.12 {
                            lastProgressTime = now
                            let elapsed = max(0.001, now - startTime)
                            let fps = Double(encodedFrames) / elapsed
                            let progress = min(0.98, max(0.0, ptsSeconds / totalDurationSeconds))
                            let eta = progress > 0.02 ? Int(((elapsed / progress) * (1.0 - progress)).rounded()) : 0
                            onProgress([
                                "taskId": taskId,
                                "progress": progress,
                                "fps": fps,
                                "etaSeconds": max(0, eta),
                                "status": "running"
                            ])
                        }
                    } else {
                        videoInput.markAsFinished()
                        dispatchGroup.leave()
                        break
                    }
                }
            }

            if let aOut = audioOutput, let aIn = audioInput {
                dispatchGroup.enter()
                aIn.requestMediaDataWhenReady(on: audioQueue) {
                    while aIn.isReadyForMoreMediaData {
                        if cancelToken.isCancelled {
                            aIn.markAsFinished()
                            dispatchGroup.leave()
                            return
                        }
                        if let sampleBuffer = aOut.copyNextSampleBuffer() {
                            aIn.append(sampleBuffer)
                        } else {
                            aIn.markAsFinished()
                            dispatchGroup.leave()
                            break
                        }
                    }
                }
            }

            dispatchGroup.notify(queue: DispatchQueue.global(qos: .userInitiated)) {
                if cancelToken.isCancelled {
                    writer.cancelWriting()
                    try? FileManager.default.removeItem(at: outputURL)
                    onProgress([
                        "taskId": taskId,
                        "progress": 0.0,
                        "fps": 0.0,
                        "etaSeconds": 0,
                        "status": "cancelled"
                    ])
                    completion(.failure(NSError(
                        domain: "FastVideoCompressor",
                        code: -999,
                        userInfo: [NSLocalizedDescriptionKey: "Cancelled by user"]
                    )))
                    return
                }

                writer.finishWriting {
                    if writer.status == .completed {
                        let elapsed = max(0.001, CFAbsoluteTimeGetCurrent() - startTime)
                        let avgFps = Double(encodedFrames) / elapsed
                        let outSize = (try? FileManager.default.attributesOfItem(atPath: outputPath)[.size] as? NSNumber)?.int64Value ?? 0
                        onProgress([
                            "taskId": taskId,
                            "progress": 1.0,
                            "fps": avgFps,
                            "etaSeconds": 0,
                            "status": "completed"
                        ])
                        completion(.success([
                            "taskId": taskId,
                            "outputPath": outputPath,
                            "outputSizeBytes": outSize,
                            "outputWidth": alignedWidth,
                            "outputHeight": alignedHeight,
                            "outputBitrate": targetBitrate,
                            "codecUsed": preferHevc ? "hvc1" : "avc1",
                            "averageFps": avgFps,
                            "elapsedMs": Int((elapsed * 1000.0).rounded())
                        ]))
                    } else {
                        try? FileManager.default.removeItem(at: outputURL)
                        let err = writer.error ?? NSError(
                            domain: "FastVideoCompressor",
                            code: -5,
                            userInfo: [NSLocalizedDescriptionKey: "AVAssetWriter failed to finish"]
                        )
                        completion(.failure(err))
                    }
                }
            }
        } catch {
            try? FileManager.default.removeItem(at: outputURL)
            completion(.failure(error))
        }
    }

    func saveToPhotoLibrary(path: String, completion: @escaping (Result<String, Error>) -> Void) {
        let fileURL = URL(fileURLWithPath: path)
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else {
                completion(.failure(NSError(
                    domain: "FastVideoCompressor",
                    code: -10,
                    userInfo: [NSLocalizedDescriptionKey: "Photo library permission denied"]
                )))
                return
            }
            var localIdentifier = ""
            PHPhotoLibrary.shared().performChanges({
                if let req = PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: fileURL),
                   let placeholder = req.placeholderForCreatedAsset {
                    localIdentifier = placeholder.localIdentifier
                }
            }) { success, error in
                if success {
                    completion(.success(localIdentifier))
                } else {
                    completion(.failure(error ?? NSError(
                        domain: "FastVideoCompressor",
                        code: -11,
                        userInfo: [NSLocalizedDescriptionKey: "Failed saving video to Photos"]
                    )))
                }
            }
        }
    }

    private static func rotationDegrees(from transform: CGAffineTransform) -> Int {
        let radians = atan2(transform.b, transform.a)
        let degrees = Int(round(radians * 180.0 / .pi))
        let normalized = (degrees + 360) % 360
        return normalized
    }
}
