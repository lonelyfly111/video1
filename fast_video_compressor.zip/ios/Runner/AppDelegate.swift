import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterStreamHandler {
    private let methodChannelName = "com.example.fast_video_compressor/methods"
    private let eventChannelName = "com.example.fast_video_compressor/events"

    private let transcoder = VideoToolboxTranscoder()
    private var cancelTokens: [String: TranscodeCancelToken] = [:]
    private var eventSink: FlutterEventSink?

    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        GeneratedPluginRegistrant.register(with: self)

        if let controller = window?.rootViewController as? FlutterViewController {
            let methodChannel = FlutterMethodChannel(
                name: methodChannelName,
                binaryMessenger: controller.binaryMessenger
            )
            let eventChannel = FlutterEventChannel(
                name: eventChannelName,
                binaryMessenger: controller.binaryMessenger
            )
            eventChannel.setStreamHandler(self)

            methodChannel.setMethodCallHandler { [weak self] call, result in
                self?.handleMethodCall(call: call, result: result)
            }
        }

        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }

    func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        self.eventSink = events
        return nil
    }

    func onCancel(withArguments arguments: Any?) -> FlutterError? {
        self.eventSink = nil
        return nil
    }

    private func handleMethodCall(call: FlutterMethodCall, result: @escaping FlutterResult) {
        guard let args = call.arguments as? [String: Any] else {
            result(FlutterError(code: "INVALID_ARGS", message: "Arguments dictionary expected", details: nil))
            return
        }

        switch call.method {
        case "getVideoMetadata":
            guard let path = args["path"] as? String else {
                result(FlutterError(code: "INVALID_ARGS", message: "path required", details: nil))
                return
            }
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    let info = try self.transcoder.inspectVideo(path: path)
                    DispatchQueue.main.async { result(info) }
                } catch {
                    DispatchQueue.main.async {
                        result(FlutterError(code: "METADATA_ERROR", message: error.localizedDescription, details: nil))
                    }
                }
            }

        case "compressVideo":
            guard let taskId = args["taskId"] as? String,
                  let inputPath = args["inputPath"] as? String,
                  let outputPath = args["outputPath"] as? String else {
                result(FlutterError(code: "INVALID_ARGS", message: "taskId, inputPath, outputPath required", details: nil))
                return
            }
            let targetWidth = args["targetWidth"] as? Int ?? 1280
            let targetHeight = args["targetHeight"] as? Int ?? 720
            let targetBitrate = args["targetBitrate"] as? Int ?? 2_500_000
            let targetFps = args["targetFps"] as? Int ?? 30
            let preferHevc = args["preferHevc"] as? Bool ?? true
            let audioPassthrough = args["audioPassthrough"] as? Bool ?? true

            let token = TranscodeCancelToken()
            cancelTokens[taskId] = token

            transcoder.transcode(
                taskId: taskId,
                inputPath: inputPath,
                outputPath: outputPath,
                targetWidth: targetWidth,
                targetHeight: targetHeight,
                targetBitrate: targetBitrate,
                targetFps: targetFps,
                preferHevc: preferHevc,
                audioPassthrough: audioPassthrough,
                cancelToken: token,
                onProgress: { [weak self] payload in
                    DispatchQueue.main.async {
                        self?.eventSink?(payload)
                    }
                },
                completion: { [weak self] outcome in
                    DispatchQueue.main.async {
                        self?.cancelTokens.removeValue(forKey: taskId)
                        switch outcome {
                        case .success(let data):
                            result(data)
                        case .failure(let err):
                            result(FlutterError(code: "TRANSCODE_FAILED", message: err.localizedDescription, details: nil))
                        }
                    }
                }
            )

        case "cancelTask":
            if let taskId = args["taskId"] as? String {
                cancelTokens[taskId]?.cancel()
            }
            result(true)

        case "saveToGallery":
            guard let path = args["path"] as? String else {
                result(FlutterError(code: "INVALID_ARGS", message: "path required", details: nil))
                return
            }
            transcoder.saveToPhotoLibrary(path: path) { outcome in
                DispatchQueue.main.async {
                    switch outcome {
                    case .success(let id):
                        result(id)
                    case .failure(let err):
                        result(FlutterError(code: "SAVE_FAILED", message: err.localizedDescription, details: nil))
                    }
                }
            }

        case "deleteOriginalVideo":
            guard let path = args["path"] as? String else {
                result(FlutterError(code: "INVALID_ARGS", message: "path required", details: nil))
                return
            }
            let deleted = (try? FileManager.default.removeItem(atPath: path)) != nil
            result(deleted)

        default:
            result(FlutterMethodNotImplemented)
        }
    }
}
