import 'package:fast_video_compressor/models/video_task.dart';
import 'package:fast_video_compressor/services/bitrate_advisor.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('BitrateAdvisor BPP & Smart Skip Engine Tests', () {
    const sample4kMeta = VideoMetadata(
      path: '/storage/emulated/0/DCIM/Camera/VID_4K.mp4',
      fileName: 'VID_4K.mp4',
      width: 3840,
      height: 2160,
      rotation: 90,
      durationMs: 60000,
      bitrateBps: 45000000, // 45 Mbps
      fps: 30.0,
      sizeBytes: 337500000,
      hasAudio: true,
      videoCodec: 'video/hevc',
    );

    test('Preset 1 (Social Fast) caps short edge at 720p and uses K = 0.05', () {
      final advice = BitrateAdvisor.evaluate(
        metadata: sample4kMeta,
        preset: CompressionPreset.socialFast,
      );
      expect(advice.targetWidth, 1280);
      expect(advice.targetHeight, 720);
      // 1280 * 720 * 30 * 0.05 = 1,382,400 bps
      expect(advice.targetBitrateBps, 1382400);
      expect(advice.shouldSkip, isFalse);
    });

    test('Preset 2 (HD Balanced) uses H.265 and K = 0.07', () {
      final advice = BitrateAdvisor.evaluate(
        metadata: sample4kMeta,
        preset: CompressionPreset.hdBalanced,
      );
      expect(advice.preferHevc, isTrue);
      expect(advice.bppFactorK, closeTo(0.07, 1e-6));
      expect(advice.shouldSkip, isFalse);
    });

    test('Preset 3 (Original Archive) keeps 4K resolution and uses K = 0.11', () {
      final advice = BitrateAdvisor.evaluate(
        metadata: sample4kMeta,
        preset: CompressionPreset.originalArchive,
      );
      expect(advice.targetWidth, 3840);
      expect(advice.targetHeight, 2160);
      // 3840 * 2160 * 30 * 0.11 = 27,371,520 bps
      expect(advice.targetBitrateBps, 27371520);
      expect(advice.preferHevc, isTrue);
    });

    test('Marks shouldSkip = true when source bitrate < 1.1x target bitrate', () {
      const alreadyCompressedMeta = VideoMetadata(
        path: '/storage/emulated/0/Download/low_bitrate.mp4',
        fileName: 'low_bitrate.mp4',
        width: 1920,
        height: 1080,
        rotation: 0,
        durationMs: 70000,
        bitrateBps: 1200000, // 1.2 Mbps (already well below 1080p@30fps K=0.07 ~ 4.35 Mbps)
        fps: 30.0,
        sizeBytes: 10500000,
        hasAudio: true,
        videoCodec: 'video/avc',
      );

      final advice = BitrateAdvisor.evaluate(
        metadata: alreadyCompressedMeta,
        preset: CompressionPreset.hdBalanced,
      );
      expect(advice.shouldSkip, isTrue);
      expect(advice.skipReason, '原视频已高度压缩，建议保留原片');
    });
  });
}
