# 极速高质量视频压缩工具 (`fast_video_compressor`)

基于 **Flutter 跨平台 UI + Android `MediaCodec` / `OpenGL ES` + iOS `VideoToolbox` / `AVAssetReader & AVAssetWriter`** 原生硬件加速架构打造的移动端全栈视频压缩工程。**严禁引入任何 FFmpeg 软编依赖**，实现零拷贝 GPU 硬件缩放、音轨无损直通（Audio Passthrough）、BPP 自适应码率计算与 GitHub Actions 免签名证书云端一键打包 Release APK。

---

## 一、 架构亮点与核心规范实现

### 1. SDK 与云端免密钥自动打包 (`com.example.fast_video_compressor`)
- **Gradle Kotlin DSL**：完整配备 `android/settings.gradle.kts`、`android/build.gradle.kts`、`android/app/build.gradle.kts`（`minSdk = 24`，`targetSdk = 35`，`compileSdk = 35`），并在 `AndroidManifest.xml` 声明 Android 13/14+ `READ_MEDIA_VIDEO` 分区存储权限。
- **免 `.jks` 证书直接出包**：在 `android/app/build.gradle.kts` 的 `buildTypes { release { ... } }` 中显式配置 `signingConfig = signingConfigs.getByName("debug")`，代码推送到 GitHub 后无需配置任何 Secrets 即可直接生成可安装的 ARM64 Release APK。
- **全局包名一致**：`com.example.fast_video_compressor` 在 `build.gradle.kts`、`AndroidManifest.xml` 与 Kotlin 源码目录结构中完全统一。

### 2. 双端原生硬件加速管线（零 FFmpeg 软编）
- **Android 端 (`HardwareVideoTranscoder.kt` + `gl/InputSurface.kt` + `gl/OutputSurface.kt` + `gl/TextureRenderer.kt`)**：
  - 使用 `MediaExtractor` 分离音视频轨道，`MediaCodec` 硬件解码器解码至 `SurfaceTexture` (`GL_TEXTURE_EXTERNAL_OES`)。
  - 通过自定义 OpenGL ES 2.0 着色器在 GPU 显存内直接完成零拷贝等比缩放，经由 `EGLExt.eglPresentationTimeANDROID` 送入 `MediaCodec` 硬件编码器（优先檢測并启用 `video/hevc` H.265，自动回退/支持切换 `video/avc` H.264）。
  - 完整读取并保留原视频 `KEY_ROTATION` 旋转角与色彩空间元数据（同步设置 `MediaMuxer.setOrientationHint`），彻底杜绝竖屏视频压制后横置变形。
  - 严格的 `try-finally` 硬件编解码器释放机制，任务取消或异常中断时自动清理残余临时文件。
- **iOS 端 (`VideoToolboxTranscoder.swift` + `AppDelegate.swift`)**：
  - 使用 `AVAssetReader` + `AVAssetWriter` 配合 `VideoToolbox` (`AVVideoCodecType.hevc` 与 `.h264`) 硬件编码。
  - 完整保留原视频 `preferredTransform` 旋转矩阵与色彩空间扩展属性（`ColorPrimaries` / `TransferFunction` / `YCbCrMatrix`）。

### 3. 音轨无损直通（Audio Passthrough）
- Android 端直接通过 `MediaExtractor.readSampleData` -> `MediaMuxer.writeSampleData` 拷贝压缩音频帧；iOS 端将 `AVAssetReaderTrackOutput` 与 `AVAssetWriterInput` 的 `outputSettings` 设为 `nil` 实现 SampleBuffer 直通封装。若原视频无音轨则自动跳过音频轨道。

### 4. BPP 自适应码率与智能跳过引擎 (`lib/services/bitrate_advisor.dart`)
- 公式：`TargetBitrate = TargetWidth * TargetHeight * TargetFPS * K`
  - **档位 1「极速社交分享」**：最高限制 720p，`K = 0.05`
  - **档位 2「高清均衡（默认）」**：保持原分辨率（最高 1080p/2K），H.265，`K = 0.07`
  - **档位 3「原画级存档」**：保持原分辨率（支持 4K），H.265，`K = 0.11`
  - **档位 4「自定义参数」**：支持手动选择分辨率（原画/2K/1080p/720p）、编码格式（HEVC/H.264）与目标码率滑块
- **智能防倒挂跳过**：若原视频平均码率已低于目标码率的 `1.1` 倍，自动标记 `shouldSkip = true`，并在 UI 提示 **“原视频已高度压缩，建议保留原片”**。

---

## 二、 如何使用 GitHub Actions 云端一键打包 APK

1. 解压 `fast_video_compressor.zip`，在工程根目录初始化 Git 并推送到您的 GitHub 仓库（`main` 或 `master` 分支）：
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Fast Video Compressor with MediaCodec & VideoToolbox"
   git branch -M main
   git remote add origin https://github.com/<你的用户名>/<你的仓库名>.git
   git push -u origin main
   ```
2. 打开 GitHub 仓库顶部的 **Actions** 标签页，工作流 `Build Android Release APK` 将自动运行（也可点击 **Run workflow** 手动触发）。
3. 构建完成后，在任务详情页底部的 **Artifacts** 区域下载 `fast-video-compressor-arm64-apk`，解压即可获得 `app-arm64-v8a-release.apk` 并直接安装到手机。
